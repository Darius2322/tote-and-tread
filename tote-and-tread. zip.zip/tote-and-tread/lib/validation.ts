import { z } from 'zod';

// Sanitize text to prevent XSS
export function sanitizeText(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

// Auth schemas
export const loginSchema = z.object({
  email: z.string().email('Invalid email address').max(255),
  password: z.string().min(8, 'Password must be at least 8 characters').max(128),
});

export const registerSchema = z.object({
  full_name: z.string().min(2, 'Name must be at least 2 characters').max(100)
    .regex(/^[a-zA-Z\s'-]+$/, 'Name contains invalid characters'),
  email: z.string().email('Invalid email address').max(255),
  password: z.string()
    .min(8, 'Password must be at least 8 characters')
    .max(128)
    .regex(/(?=.*[a-z])/, 'Must contain a lowercase letter')
    .regex(/(?=.*[A-Z])/, 'Must contain an uppercase letter')
    .regex(/(?=.*\d)/, 'Must contain a number'),
  confirm_password: z.string(),
}).refine(data => data.password === data.confirm_password, {
  message: 'Passwords do not match',
  path: ['confirm_password'],
});

export const resetPasswordSchema = z.object({
  email: z.string().email('Invalid email address').max(255),
});

export const updatePasswordSchema = z.object({
  password: z.string()
    .min(8).max(128)
    .regex(/(?=.*[a-z])/)
    .regex(/(?=.*[A-Z])/)
    .regex(/(?=.*\d)/),
  confirm_password: z.string(),
}).refine(data => data.password === data.confirm_password, {
  message: 'Passwords do not match',
  path: ['confirm_password'],
});

// Profile schema
export const updateProfileSchema = z.object({
  full_name: z.string().min(2).max(100).optional(),
  phone: z.string().regex(/^\+?[\d\s\-()]{7,20}$/, 'Invalid phone number').optional().or(z.literal('')),
  theme_preference: z.enum(['light', 'dark', 'system']).optional(),
});

// Product schema (admin)
export const productSchema = z.object({
  name: z.string().min(2).max(200),
  description: z.string().max(5000).optional(),
  price: z.number().min(0).max(9999999),
  compare_at_price: z.number().min(0).max(9999999).optional(),
  category_id: z.string().uuid().optional(),
  stock_quantity: z.number().int().min(0),
  low_stock_threshold: z.number().int().min(0).default(5),
  badge: z.enum(['trending', 'best_seller', 'premium', 'new', 'sale']).optional(),
  is_active: z.boolean().default(true),
  is_featured: z.boolean().default(false),
  sizes: z.array(z.string()).default([]),
  colors: z.array(z.string()).default([]),
  tags: z.array(z.string()).default([]),
  meta_title: z.string().max(70).optional(),
  meta_description: z.string().max(160).optional(),
});

// Review schema
export const reviewSchema = z.object({
  product_id: z.string().uuid(),
  rating: z.number().int().min(1).max(5),
  title: z.string().max(100).optional(),
  body: z.string().max(2000).optional(),
});

// Checkout/address schema
export const addressSchema = z.object({
  full_name: z.string().min(2).max(100),
  phone: z.string().regex(/^\+?[\d\s\-()]{7,20}$/),
  address_line1: z.string().min(5).max(200),
  address_line2: z.string().max(200).optional(),
  city: z.string().min(2).max(100),
  county: z.string().max(100).optional(),
  country: z.string().default('Kenya'),
  postal_code: z.string().max(20).optional(),
  is_default: z.boolean().default(false),
});

export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
export type ProductInput = z.infer<typeof productSchema>;
export type ReviewInput = z.infer<typeof reviewSchema>;
export type AddressInput = z.infer<typeof addressSchema>;
