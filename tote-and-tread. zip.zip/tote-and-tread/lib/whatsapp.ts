export interface WhatsAppOrderData {
  customerName: string;
  customerPhone?: string;
  items: {
    name: string;
    quantity: number;
    price: number;
    size?: string;
    color?: string;
  }[];
  total: number;
  deliveryDetails?: string;
  orderNumber?: string;
  currency?: string;
}

export function generateWhatsAppOrderMessage(order: WhatsAppOrderData): string {
  const symbol = order.currency === 'KES' ? 'KSh' : '$';
  const lines = [
    '🛍️ *NEW ORDER - TOTE & TREAD*',
    '━━━━━━━━━━━━━━━━━━━━',
    `📦 *Order #:* ${order.orderNumber || 'New'}`,
    `👤 *Customer:* ${order.customerName}`,
    order.customerPhone ? `📱 *Phone:* ${order.customerPhone}` : '',
    '',
    '*ITEMS ORDERED:*',
    ...order.items.map(item => [
      `▪️ ${item.name}`,
      `   Qty: ${item.quantity} × ${symbol}${item.price.toLocaleString()}`,
      item.size ? `   Size: ${item.size}` : '',
      item.color ? `   Color: ${item.color}` : '',
    ].filter(Boolean).join('\n')),
    '',
    '━━━━━━━━━━━━━━━━━━━━',
    `💰 *TOTAL: ${symbol}${order.total.toLocaleString()}*`,
    '',
    order.deliveryDetails ? `🚚 *Delivery Details:*\n${order.deliveryDetails}` : '',
    '',
    `_Sent via Tote & Tread Website_`,
  ].filter(line => line !== undefined);

  return lines.join('\n');
}

export function getWhatsAppUrl(phone: string, message: string): string {
  const cleanPhone = phone.replace(/\D/g, '');
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${cleanPhone}?text=${encodedMessage}`;
}
