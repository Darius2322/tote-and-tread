import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

export interface ApiResponse<T = unknown> {
  data?: T;
  error?: string;
  message?: string;
}

export function successResponse<T>(data: T, status = 200) {
  return NextResponse.json({ data } as ApiResponse<T>, { status });
}

export function errorResponse(error: string, status = 400) {
  return NextResponse.json({ error } as ApiResponse, { status });
}

// Require authenticated user
export async function requireAuth() {
  const supabase = await createClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) throw new Error('Unauthorized');
  return { supabase, user };
}

// Require admin role
export async function requireAdmin() {
  const { supabase, user } = await requireAuth();
  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();
  if (!profile || profile.role !== 'admin') throw new Error('Forbidden');
  return { supabase, user, profile };
}

// Wrap route handlers with error handling
export function withErrorHandling(handler: Function) {
  return async (...args: unknown[]) => {
    try {
      return await handler(...args);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Internal server error';
      if (message === 'Unauthorized') return errorResponse('Unauthorized', 401);
      if (message === 'Forbidden') return errorResponse('Forbidden', 403);
      console.error('[API Error]', err);
      return errorResponse('Internal server error', 500);
    }
  };
}
