# App Icons

Generate icons from your logo using:
  npx pwa-asset-generator logo.png ./public/icons

Required sizes:
- icon-72.png
- icon-96.png  
- icon-128.png
- icon-144.png
- icon-152.png
- icon-180.png (Apple Touch Icon)
- icon-192.png (PWA)
- icon-512.png (PWA)
