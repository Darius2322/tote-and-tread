import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Product } from '@/lib/types';

interface WishlistStore {
  items: Product[];
  toggleItem: (id: string, product: Product) => void;
  isWishlisted: (id: string) => boolean;
  clear: () => void;
}

export const useWishlistStore = create<WishlistStore>()(
  persist(
    (set, get) => ({
      items: [],
      toggleItem: (id, product) => {
        set((state) => {
          const exists = state.items.some((i) => i.id === id);
          return {
            items: exists
              ? state.items.filter((i) => i.id !== id)
              : [...state.items, product],
          };
        });
      },
      isWishlisted: (id) => get().items.some((i) => i.id === id),
      clear: () => set({ items: [] }),
    }),
    { name: 'tote-tread-wishlist', version: 1 }
  )
);
