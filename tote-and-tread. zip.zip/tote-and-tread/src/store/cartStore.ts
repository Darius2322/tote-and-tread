import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Product } from '@/lib/types';

interface CartItem {
  product: Product;
  quantity: number;
  size?: string;
  color?: string;
}

interface CartStore {
  items: CartItem[];
  totalItems: number;
  totalPrice: number;
  addItem: (item: Omit<CartItem, 'id'>) => void;
  removeItem: (productId: string, size?: string, color?: string) => void;
  updateQuantity: (productId: string, quantity: number, size?: string, color?: string) => void;
  clearCart: () => void;
  getItemCount: (productId: string) => number;
}

function computeTotals(items: CartItem[]) {
  return {
    totalItems: items.reduce((sum, i) => sum + i.quantity, 0),
    totalPrice: items.reduce((sum, i) => sum + i.product.price * i.quantity, 0),
  };
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      totalItems: 0,
      totalPrice: 0,

      addItem: ({ product, quantity, size, color }) => {
        set((state) => {
          const existing = state.items.find(
            (i) => i.product.id === product.id && i.size === size && i.color === color
          );
          
          let newItems: CartItem[];
          if (existing) {
            newItems = state.items.map((i) =>
              i.product.id === product.id && i.size === size && i.color === color
                ? { ...i, quantity: Math.min(i.quantity + quantity, product.stock_qty) }
                : i
            );
          } else {
            newItems = [...state.items, { product, quantity, size, color }];
          }
          
          return { items: newItems, ...computeTotals(newItems) };
        });
      },

      removeItem: (productId, size, color) => {
        set((state) => {
          const newItems = state.items.filter(
            (i) => !(i.product.id === productId && i.size === size && i.color === color)
          );
          return { items: newItems, ...computeTotals(newItems) };
        });
      },

      updateQuantity: (productId, quantity, size, color) => {
        if (quantity <= 0) {
          get().removeItem(productId, size, color);
          return;
        }
        set((state) => {
          const newItems = state.items.map((i) =>
            i.product.id === productId && i.size === size && i.color === color
              ? { ...i, quantity: Math.min(quantity, i.product.stock_qty) }
              : i
          );
          return { items: newItems, ...computeTotals(newItems) };
        });
      },

      clearCart: () => set({ items: [], totalItems: 0, totalPrice: 0 }),

      getItemCount: (productId) => {
        return get().items
          .filter((i) => i.product.id === productId)
          .reduce((sum, i) => sum + i.quantity, 0);
      },
    }),
    {
      name: 'tote-tread-cart',
      version: 1,
    }
  )
);
