import { z } from 'zod';

// ─── XSS-safe sanitization ───────────────────────────────────────────────────
// Server-safe: strips all HTML tags
export function sanitizeText(input: string): string {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;')
    .trim();
}

// Strip HTML tags entirely (for plain text fields)
export function stripHtml(input: string): string {
  return input.replace(/<[^>]*>/g, '').trim();
}

// ─── Zod validation schemas ──────────────────────────────────────────────────

export const registerSchema = z.object({
  full_name: z
    .string()
    .min(2, 'Name must be at least 2 characters')
    .max(100, 'Name too long')
    .transform(stripHtml),
  email: z
    .string()
    .email('Invalid email address')
    .toLowerCase()
    .max(255),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(72, 'Password too long')
    .regex(/[A-Z]/, 'Must contain an uppercase letter')
    .regex(/[0-9]/, 'Must contain a number')
    .regex(/[^A-Za-z0-9]/, 'Must contain a special character'),
  confirmPassword: z.string(),
}).refine((d) => d.password === d.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

export const loginSchema = z.object({
  email: z.string().email('Invalid email').toLowerCase().max(255),
  password: z.string().min(1, 'Password is required').max(72),
});

export const profileUpdateSchema = z.object({
  full_name: z.string().min(2).max(100).transform(stripHtml).optional(),
  phone: z
    .string()
    .regex(/^\+?[0-9\s\-()]{7,20}$/, 'Invalid phone number')
    .optional()
    .or(z.literal('')),
  address_line1: z.string().max(200).transform(stripHtml).optional(),
  address_line2: z.string().max(200).transform(stripHtml).optional(),
  city: z.string().max(100).transform(stripHtml).optional(),
  country: z.string().max(100).optional(),
  postal_code: z.string().max(20).optional(),
});

export const productSchema = z.object({
  name: z.string().min(2).max(200).transform(stripHtml),
  slug: z
    .string()
    .min(2)
    .max(200)
    .regex(/^[a-z0-9-]+$/, 'Slug can only contain lowercase letters, numbers, and hyphens'),
  description: z.string().min(10).max(5000).transform(stripHtml),
  short_desc: z.string().max(500).transform(stripHtml).optional(),
  price: z.number().positive().max(1_000_000),
  compare_price: z.number().positive().max(1_000_000).optional().nullable(),
  category: z.enum(['handbags', 'travel_bags', 'sneakers', 'formal_shoes', 'accessories']),
  stock_qty: z.number().int().min(0).max(100_000),
  low_stock_threshold: z.number().int().min(0).max(1000).default(5),
  sku: z.string().max(100).optional().nullable(),
  tags: z.array(z.string().max(50)).max(20).default([]),
  sizes: z.array(z.string().max(20)).max(20).default([]),
  colors: z.array(z.string().max(50)).max(10).default([]),
  is_trending: z.boolean().default(false),
  is_bestseller: z.boolean().default(false),
  is_premium: z.boolean().default(false),
  is_featured: z.boolean().default(false),
  meta_title: z.string().max(60).optional().nullable(),
  meta_desc: z.string().max(160).optional().nullable(),
});

export const reviewSchema = z.object({
  product_id: z.string().uuid(),
  rating: z.number().int().min(1).max(5),
  title: z.string().min(2).max(100).transform(stripHtml).optional(),
  body: z.string().min(10).max(2000).transform(stripHtml),
});

export const checkoutSchema = z.object({
  full_name: z.string().min(2).max(100).transform(stripHtml),
  phone: z
    .string()
    .regex(/^\+?[0-9\s\-()]{7,20}$/, 'Invalid phone number'),
  address: z.string().min(5).max(300).transform(stripHtml),
  city: z.string().min(2).max(100).transform(stripHtml),
  notes: z.string().max(500).transform(stripHtml).optional(),
});

export const promotionSchema = z.object({
  title: z.string().min(2).max(200).transform(stripHtml),
  description: z.string().max(1000).transform(stripHtml).optional(),
  button_label: z.string().max(50).transform(stripHtml).optional(),
  button_url: z.string().url().optional().or(z.literal('')),
  display_type: z.enum(['banner', 'popup', 'notification_bar']),
  scheduled_at: z.string().datetime().optional().nullable(),
  expires_at: z.string().datetime().optional().nullable(),
  priority: z.number().int().min(0).max(100).default(0),
});

// ─── SQL injection prevention helpers ───────────────────────────────────────
// Supabase uses parameterized queries automatically, but here are helpers
// for any raw SQL you might write.

export function isUUID(value: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
}

export function validateUUID(value: unknown): string {
  if (typeof value !== 'string' || !isUUID(value)) {
    throw new Error('Invalid ID format');
  }
  return value;
}

// ─── Pagination validation ───────────────────────────────────────────────────
export function parsePagination(
  page: unknown,
  perPage: unknown,
  maxPerPage = 100
): { page: number; perPage: number; from: number; to: number } {
  const p = Math.max(1, parseInt(String(page || 1), 10) || 1);
  const pp = Math.min(
    maxPerPage,
    Math.max(1, parseInt(String(perPage || 20), 10) || 20)
  );
  return {
    page: p,
    perPage: pp,
    from: (p - 1) * pp,
    to: p * pp - 1,
  };
}

// ─── Search query sanitization ───────────────────────────────────────────────
export function sanitizeSearchQuery(query: string): string {
  return query
    .trim()
    .slice(0, 200)
    .replace(/[^\w\s\-']/g, '') // Only allow word chars, spaces, hyphens, apostrophes
    .trim();
}

// ─── Slug generation ─────────────────────────────────────────────────────────
export function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim();
}

// ─── Validate file upload ────────────────────────────────────────────────────
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

export function validateImageFile(file: File): { valid: boolean; error?: string } {
  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
    return { valid: false, error: 'Only JPEG, PNG, and WebP images are allowed' };
  }
  if (file.size > MAX_FILE_SIZE) {
    return { valid: false, error: 'Image must be smaller than 5MB' };
  }
  return { valid: true };
}

// ─── API error response helper ───────────────────────────────────────────────
export function createErrorResponse(
  message: string,
  status: number = 400
): Response {
  return Response.json({ error: message }, { status });
}

export function createSuccessResponse<T>(
  data: T,
  status: number = 200
): Response {
  return Response.json({ data }, { status });
}
