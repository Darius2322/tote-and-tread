// ============================================================
// Tote & Tread — Core Types
// ============================================================

export type UserRole = 'customer' | 'admin' | 'moderator';
export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
export type ProductCategory = 'handbags' | 'travel_bags' | 'sneakers' | 'formal_shoes' | 'accessories';
export type NotificationType = 'order_update' | 'promotion' | 'restock' | 'system';
export type PromotionDisplay = 'banner' | 'popup' | 'notification_bar';
export type Theme = 'dark' | 'light' | 'system';

// ─── Database row types ──────────────────────────────────────────────────────

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  phone: string | null;
  role: UserRole;
  theme_pref: Theme;
  address_line1: string | null;
  address_line2: string | null;
  city: string | null;
  country: string;
  postal_code: string | null;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  short_desc: string | null;
  price: number;
  compare_price: number | null;
  category: ProductCategory;
  brand: string;
  stock_qty: number;
  low_stock_threshold: number;
  sku: string | null;
  images: string[];
  thumbnail: string | null;
  tags: string[];
  sizes: string[];
  colors: string[];
  weight_kg: number | null;
  is_trending: boolean;
  is_bestseller: boolean;
  is_premium: boolean;
  is_featured: boolean;
  is_active: boolean;
  view_count: number;
  purchase_count: number;
  meta_title: string | null;
  meta_desc: string | null;
  created_at: string;
  updated_at: string;
  // Computed
  avg_rating?: number;
  review_count?: number;
}

export interface Review {
  id: string;
  product_id: string;
  user_id: string;
  rating: 1 | 2 | 3 | 4 | 5;
  title: string | null;
  body: string | null;
  is_verified: boolean;
  created_at: string;
  profiles?: Pick<Profile, 'full_name' | 'avatar_url'>;
}

export interface CartItem {
  id: string;
  user_id: string;
  product_id: string;
  quantity: number;
  size: string | null;
  color: string | null;
  created_at: string;
  updated_at: string;
  products?: Product;
}

export interface WishlistItem {
  id: string;
  user_id: string;
  product_id: string;
  created_at: string;
  products?: Product;
}

export interface Order {
  id: string;
  order_number: string;
  user_id: string;
  status: OrderStatus;
  subtotal: number;
  discount_amount: number;
  shipping_amount: number;
  total: number;
  delivery_name: string;
  delivery_phone: string;
  delivery_address: string;
  delivery_city: string;
  delivery_notes: string | null;
  whatsapp_sent: boolean;
  payment_ref: string | null;
  created_at: string;
  updated_at: string;
  order_items?: OrderItem[];
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  product_img: string | null;
  price: number;
  quantity: number;
  size: string | null;
  color: string | null;
  subtotal: number;
}

export interface Receipt {
  id: string;
  receipt_number: string;
  order_id: string;
  user_id: string;
  pdf_url: string | null;
  generated_at: string;
  orders?: Order;
}

export interface Notification {
  id: string;
  user_id: string;
  type: NotificationType;
  title: string;
  body: string;
  action_url: string | null;
  is_read: boolean;
  created_at: string;
}

export interface Promotion {
  id: string;
  title: string;
  description: string | null;
  image_url: string | null;
  button_label: string | null;
  button_url: string | null;
  display_type: PromotionDisplay;
  is_active: boolean;
  scheduled_at: string | null;
  expires_at: string | null;
  priority: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface GalleryItem {
  id: string;
  image_url: string;
  alt_text: string | null;
  caption: string | null;
  sort_order: number;
  is_active: boolean;
  created_at: string;
}

// ─── API / Form types ────────────────────────────────────────────────────────

export interface ApiResponse<T = unknown> {
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  per_page: number;
  total_pages: number;
}

export interface ProductFilters {
  category?: ProductCategory;
  minPrice?: number;
  maxPrice?: number;
  tags?: string[];
  sizes?: string[];
  colors?: string[];
  inStock?: boolean;
  search?: string;
  sortBy?: 'price_asc' | 'price_desc' | 'newest' | 'popular' | 'rating';
}

export interface CheckoutFormData {
  full_name: string;
  phone: string;
  address: string;
  city: string;
  notes?: string;
}

export interface AdminStats {
  total_users: number;
  total_products: number;
  total_orders: number;
  revenue_total: number;
  orders_today: number;
  revenue_today: number;
  pending_orders: number;
  low_stock_products: number;
}

export interface WhatsAppOrderPayload {
  orderNumber: string;
  customerName: string;
  phone: string;
  items: Array<{
    name: string;
    quantity: number;
    price: number;
    size?: string;
    color?: string;
  }>;
  subtotal: number;
  total: number;
  deliveryAddress: string;
  city: string;
  notes?: string;
}
