'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';

export function HeroSection() {
  return (
    <section className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background */}
      <motion.div
        className="absolute inset-0 z-0"
        initial={{ scale: 1.1 }}
        animate={{ scale: 1 }}
        transition={{ duration: 8, ease: 'easeOut' }}
        style={{
          background: `
            radial-gradient(ellipse at 20% 50%, rgba(201, 168, 76, 0.08) 0%, transparent 60%),
            radial-gradient(ellipse at 80% 20%, rgba(201, 168, 76, 0.05) 0%, transparent 50%),
            var(--bg)
          `,
        }}
      />

      {/* Decorative lines */}
      <div className="absolute inset-0 z-0 overflow-hidden opacity-20">
        <div className="absolute top-0 left-1/4 w-px h-full" 
             style={{ background: 'linear-gradient(to bottom, transparent, var(--gold), transparent)' }} />
        <div className="absolute top-0 right-1/4 w-px h-full" 
             style={{ background: 'linear-gradient(to bottom, transparent, var(--gold), transparent)' }} />
        <div className="absolute top-1/4 left-0 h-px w-full" 
             style={{ background: 'linear-gradient(to right, transparent, var(--gold), transparent)' }} />
        <div className="absolute top-3/4 left-0 h-px w-full" 
             style={{ background: 'linear-gradient(to right, transparent, var(--gold), transparent)' }} />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        {/* Brand symbol */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex items-center justify-center gap-3 mb-8"
        >
          <div className="h-px w-16" style={{ background: 'var(--gold)' }} />
          <span className="section-subtitle">Est. 2024</span>
          <div className="h-px w-16" style={{ background: 'var(--gold)' }} />
        </motion.div>

        {/* Brand name */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="font-cormorant font-light leading-none tracking-[0.08em] mb-6"
          style={{ fontSize: 'clamp(3.5rem, 10vw, 8rem)', color: 'var(--text-primary)' }}
        >
          Tote <span className="text-gradient-gold">&</span> Tread
        </motion.h1>

        {/* Divider */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="divider-gold mb-8 mx-auto w-48"
        />

        {/* Slogan */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.0 }}
          className="font-jost font-light tracking-[0.3em] uppercase text-sm md:text-base mb-12"
          style={{ color: 'var(--text-secondary)' }}
        >
          Step Into Style. Carry Confidence.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.2 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Link href="/products" className="btn-gold inline-block">
            Shop Collection
          </Link>
          <Link href="/about" className="btn-outline-gold inline-block">
            Our Story
          </Link>
        </motion.div>

        {/* Category pills */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1.5 }}
          className="flex flex-wrap justify-center gap-3 mt-12"
        >
          {['Handbags', 'Travel Bags', 'Sneakers', 'Formal Shoes'].map((cat) => (
            <Link
              key={cat}
              href={`/products?category=${cat.toLowerCase().replace(' ', '_')}`}
              className="text-xs tracking-[0.2em] uppercase px-4 py-2 transition-colors"
              style={{
                border: '1px solid var(--border)',
                color: 'var(--text-muted)',
              }}
              onMouseEnter={(e) => {
                (e.target as HTMLElement).style.borderColor = 'var(--gold)';
                (e.target as HTMLElement).style.color = 'var(--gold)';
              }}
              onMouseLeave={(e) => {
                (e.target as HTMLElement).style.borderColor = 'var(--border)';
                (e.target as HTMLElement).style.color = 'var(--text-muted)';
              }}
            >
              {cat}
            </Link>
          ))}
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-xs tracking-[0.3em] uppercase" style={{ color: 'var(--text-muted)' }}>
          Scroll
        </span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          className="w-px h-8"
          style={{ background: 'linear-gradient(to bottom, var(--gold), transparent)' }}
        />
      </motion.div>
    </section>
  );
}
