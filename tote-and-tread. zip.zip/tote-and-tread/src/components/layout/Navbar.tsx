'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useTheme } from 'next-themes';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingBag, Heart, Search, User, Sun, Moon, Menu, X } from 'lucide-react';
import { useCartStore } from '@/store/cartStore';

export function Navbar() {
  const { theme, setTheme } = useTheme();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const cartCount = useCartStore((s) => s.totalItems);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '/', label: 'Home' },
    { href: '/products', label: 'Shop' },
    { href: '/products?category=handbags', label: 'Handbags' },
    { href: '/products?category=sneakers', label: 'Footwear' },
    { href: '/about', label: 'About' },
    { href: '/gallery', label: 'Gallery' },
  ];

  return (
    <>
      <header
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
        style={{
          background: scrolled ? 'var(--bg)' : 'transparent',
          borderBottom: scrolled ? '1px solid var(--border)' : '1px solid transparent',
          backdropFilter: scrolled ? 'blur(20px)' : 'none',
        }}
      >
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 z-10">
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                <rect width="32" height="32" fill="none"/>
                <path d="M6 26 L16 6 L26 26" stroke="var(--gold)" strokeWidth="1.5" fill="none" strokeLinejoin="round"/>
                <path d="M9 20 L23 20" stroke="var(--gold)" strokeWidth="1.5"/>
                <circle cx="16" cy="6" r="2" fill="var(--gold)"/>
              </svg>
              <span className="font-cormorant text-xl font-medium tracking-[0.1em]" 
                    style={{ color: 'var(--text-primary)' }}>
                Tote <span style={{ color: 'var(--gold)' }}>&</span> Tread
              </span>
            </Link>

            {/* Desktop nav */}
            <nav className="hidden md:flex items-center gap-8">
              {navLinks.map(({ href, label }) => (
                <Link
                  key={href}
                  href={href}
                  className="text-xs tracking-[0.2em] uppercase transition-colors duration-200"
                  style={{ color: 'var(--text-secondary)' }}
                  onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--gold)')}
                  onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--text-secondary)')}
                >
                  {label}
                </Link>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-3 md:gap-4">
              {/* Search */}
              <button
                onClick={() => setSearchOpen(true)}
                className="p-2 transition-colors"
                style={{ color: 'var(--text-secondary)' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--gold)')}
                onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--text-secondary)')}
                aria-label="Search"
              >
                <Search size={18} />
              </button>

              {/* Theme toggle */}
              <button
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="p-2 transition-colors"
                style={{ color: 'var(--text-secondary)' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--gold)')}
                onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--text-secondary)')}
                aria-label="Toggle theme"
              >
                {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
              </button>

              {/* Wishlist */}
              <Link
                href="/dashboard/wishlist"
                className="p-2 transition-colors hidden sm:block"
                style={{ color: 'var(--text-secondary)' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--gold)')}
                onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--text-secondary)')}
                aria-label="Wishlist"
              >
                <Heart size={18} />
              </Link>

              {/* Cart */}
              <Link href="/cart" className="relative p-2 transition-colors" aria-label="Cart"
                style={{ color: 'var(--text-secondary)' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--gold)')}
                onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--text-secondary)')}
              >
                <ShoppingBag size={18} />
                {cartCount > 0 && (
                  <span
                    className="absolute -top-0.5 -right-0.5 w-4 h-4 text-xs flex items-center justify-center rounded-full font-bold"
                    style={{ background: 'var(--gold)', color: '#000' }}
                  >
                    {cartCount > 9 ? '9+' : cartCount}
                  </span>
                )}
              </Link>

              {/* Account */}
              <Link
                href="/dashboard"
                className="p-2 transition-colors hidden sm:block"
                style={{ color: 'var(--text-secondary)' }}
                onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--gold)')}
                onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--text-secondary)')}
                aria-label="Account"
              >
                <User size={18} />
              </Link>

              {/* Mobile menu */}
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="p-2 md:hidden"
                style={{ color: 'var(--text-secondary)' }}
                aria-label="Menu"
              >
                {menuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="fixed inset-0 z-40 md:hidden"
            style={{ background: 'var(--bg)' }}
          >
            <div className="flex flex-col items-center justify-center h-full gap-8 p-8">
              {navLinks.map(({ href, label }, i) => (
                <motion.div
                  key={href}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.07 }}
                >
                  <Link
                    href={href}
                    onClick={() => setMenuOpen(false)}
                    className="font-cormorant text-3xl font-light tracking-[0.1em]"
                    style={{ color: 'var(--text-primary)' }}
                  >
                    {label}
                  </Link>
                </motion.div>
              ))}
              <div className="divider-gold w-24" />
              <div className="flex gap-6">
                <Link href="/dashboard" onClick={() => setMenuOpen(false)}
                  className="text-xs tracking-[0.2em] uppercase" style={{ color: 'var(--text-muted)' }}>
                  Account
                </Link>
                <Link href="/dashboard/wishlist" onClick={() => setMenuOpen(false)}
                  className="text-xs tracking-[0.2em] uppercase" style={{ color: 'var(--text-muted)' }}>
                  Wishlist
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search overlay */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div
            initial={{ opacity: 0, y: -100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -100 }}
            transition={{ duration: 0.3 }}
            className="fixed top-0 left-0 right-0 z-50 shadow-2xl"
            style={{ background: 'var(--bg)', borderBottom: '1px solid var(--border)' }}
          >
            <div className="max-w-2xl mx-auto px-4 py-4">
              <div className="flex items-center gap-3">
                <Search size={18} style={{ color: 'var(--gold)' }} />
                <input
                  autoFocus
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && searchQuery.trim()) {
                      window.location.href = `/search?q=${encodeURIComponent(searchQuery.trim())}`;
                    }
                    if (e.key === 'Escape') setSearchOpen(false);
                  }}
                  placeholder="Search bags, shoes, collections..."
                  className="flex-1 bg-transparent outline-none text-base"
                  style={{ color: 'var(--text-primary)', fontFamily: 'var(--font-jost)' }}
                />
                <button onClick={() => setSearchOpen(false)} style={{ color: 'var(--text-muted)' }}>
                  <X size={18} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Spacer */}
      <div className="h-16 md:h-20" />
    </>
  );
}
