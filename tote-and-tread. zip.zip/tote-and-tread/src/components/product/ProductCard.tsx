'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { Heart, ShoppingBag, Share2, Star } from 'lucide-react';
import { useCartStore } from '@/store/cartStore';
import { useWishlistStore } from '@/store/wishlistStore';
import toast from 'react-hot-toast';
import type { Product } from '@/lib/types';

interface ProductCardProps {
  product: Product;
  priority?: boolean;
}

export function ProductCard({ product, priority = false }: ProductCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const addToCart = useCartStore((s) => s.addItem);
  const toggleWishlist = useWishlistStore((s) => s.toggleItem);
  const isWishlisted = useWishlistStore((s) => s.isWishlisted(product.id));

  const imageUrl = product.thumbnail || product.images[0];
  const hoverImageUrl = product.images[1];
  const discountPct = product.compare_price
    ? Math.round(((product.compare_price - product.price) / product.compare_price) * 100)
    : null;
  const isLowStock =
    product.stock_qty <= product.low_stock_threshold && product.stock_qty > 0;
  const isOutOfStock = product.stock_qty === 0;

  function handleAddToCart(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (isOutOfStock) return;
    addToCart({ product, quantity: 1 });
    toast.success(`${product.name} added to cart`);
  }

  function handleWishlist(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product.id, product);
    toast.success(isWishlisted ? 'Removed from wishlist' : 'Saved to wishlist');
  }

  async function handleShare(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    const url = `${window.location.origin}/products/${product.slug}`;
    if (navigator.share) {
      await navigator.share({ title: product.name, url });
    } else {
      await navigator.clipboard.writeText(url);
      toast.success('Link copied to clipboard');
    }
  }

  return (
    <motion.div
      className="group card-luxury relative overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <Link href={`/products/${product.slug}`} className="block">
        {/* Image */}
        <div className="relative aspect-[3/4] overflow-hidden" style={{ background: 'var(--bg-secondary)' }}>
          {!imageLoaded && (
            <div className="absolute inset-0 animate-shimmer" />
          )}
          
          {imageUrl && (
            <Image
              src={imageUrl}
              alt={product.name}
              fill
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
              className={`object-cover transition-all duration-700 ${
                isHovered && hoverImageUrl ? 'opacity-0' : 'opacity-100'
              }`}
              onLoad={() => setImageLoaded(true)}
              priority={priority}
            />
          )}
          
          {/* Hover image */}
          {hoverImageUrl && (
            <Image
              src={hoverImageUrl}
              alt={`${product.name} alternate`}
              fill
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
              className={`object-cover transition-all duration-700 absolute inset-0 ${
                isHovered ? 'opacity-100' : 'opacity-0'
              }`}
            />
          )}

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
            {product.is_trending && (
              <span className="badge-trending text-xs px-2 py-0.5">🔥 Trending</span>
            )}
            {product.is_bestseller && (
              <span className="badge-bestseller text-xs px-2 py-0.5">⭐ Best Seller</span>
            )}
            {product.is_premium && (
              <span className="badge-premium text-xs px-2 py-0.5">💎 Premium</span>
            )}
            {discountPct && discountPct > 0 && (
              <span className="text-xs px-2 py-0.5 font-bold" 
                    style={{ background: '#ef4444', color: '#fff' }}>
                -{discountPct}%
              </span>
            )}
          </div>

          {/* Out of stock overlay */}
          {isOutOfStock && (
            <div className="absolute inset-0 flex items-center justify-center z-10"
                 style={{ background: 'rgba(0,0,0,0.5)' }}>
              <span className="text-xs tracking-[0.2em] uppercase font-medium" 
                    style={{ color: '#fff' }}>Sold Out</span>
            </div>
          )}

          {/* Low stock alert */}
          {isLowStock && !isOutOfStock && (
            <div className="absolute bottom-3 left-3 right-3 z-10">
              <span className="text-xs px-2 py-1 block text-center"
                    style={{ background: 'rgba(201,168,76,0.15)', border: '1px solid var(--gold)', color: 'var(--gold)' }}>
                Only {product.stock_qty} left
              </span>
            </div>
          )}

          {/* Action buttons — appear on hover */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: isHovered ? 1 : 0 }}
            transition={{ duration: 0.2 }}
            className="absolute top-3 right-3 flex flex-col gap-2 z-20"
          >
            <button
              onClick={handleWishlist}
              className="w-8 h-8 flex items-center justify-center rounded-full transition-all"
              style={{
                background: 'var(--bg)',
                border: `1px solid ${isWishlisted ? 'var(--gold)' : 'var(--border)'}`,
                color: isWishlisted ? 'var(--gold)' : 'var(--text-secondary)',
              }}
              aria-label="Save to wishlist"
            >
              <Heart size={14} fill={isWishlisted ? 'currentColor' : 'none'} />
            </button>
            <button
              onClick={handleShare}
              className="w-8 h-8 flex items-center justify-center rounded-full transition-all"
              style={{
                background: 'var(--bg)',
                border: '1px solid var(--border)',
                color: 'var(--text-secondary)',
              }}
              aria-label="Share product"
            >
              <Share2 size={14} />
            </button>
          </motion.div>
        </div>

        {/* Info */}
        <div className="p-4">
          <p className="text-xs tracking-[0.15em] uppercase mb-1" style={{ color: 'var(--text-muted)' }}>
            {product.category.replace('_', ' ')}
          </p>
          <h3 className="font-cormorant text-lg font-medium mb-2 line-clamp-1"
              style={{ color: 'var(--text-primary)' }}>
            {product.name}
          </h3>
          
          {/* Rating */}
          {product.avg_rating && (
            <div className="flex items-center gap-1 mb-2">
              {Array(5).fill(0).map((_, i) => (
                <Star
                  key={i}
                  size={11}
                  fill={i < Math.round(product.avg_rating!) ? 'var(--gold)' : 'none'}
                  stroke="var(--gold)"
                />
              ))}
              {product.review_count && (
                <span className="text-xs ml-1" style={{ color: 'var(--text-muted)' }}>
                  ({product.review_count})
                </span>
              )}
            </div>
          )}

          {/* Price */}
          <div className="flex items-center gap-2">
            <span className="font-jost font-semibold text-lg" style={{ color: 'var(--gold)' }}>
              KES {product.price.toLocaleString()}
            </span>
            {product.compare_price && (
              <span className="text-sm line-through" style={{ color: 'var(--text-muted)' }}>
                KES {product.compare_price.toLocaleString()}
              </span>
            )}
          </div>
        </div>
      </Link>

      {/* Add to cart button */}
      <div className="px-4 pb-4">
        <button
          onClick={handleAddToCart}
          disabled={isOutOfStock}
          className="w-full btn-outline-gold text-xs py-2.5 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <ShoppingBag size={14} />
          {isOutOfStock ? 'Sold Out' : 'Add to Cart'}
        </button>
      </div>
    </motion.div>
  );
}
