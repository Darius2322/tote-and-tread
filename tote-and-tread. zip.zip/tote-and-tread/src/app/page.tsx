import { Suspense } from 'react';
import { createClient } from '@/lib/supabase/server';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { HeroSection } from '@/components/home/HeroSection';
import { CategoryGrid } from '@/components/home/CategoryGrid';
import { FeaturedProducts } from '@/components/home/FeaturedProducts';
import { TrendingSlider } from '@/components/home/TrendingSlider';
import { PromotionBanner } from '@/components/home/PromotionBanner';
import { WhatsAppButton } from '@/components/ui/WhatsAppButton';
import { ExitIntentPopup } from '@/components/home/ExitIntentPopup';
import { ProductSkeleton } from '@/components/product/ProductSkeleton';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Tote & Tread — Luxury Bags & Footwear',
  description: 'Step Into Style. Carry Confidence. Premium luxury handbags, travel bags, sneakers & formal shoes.',
};

export const revalidate = 60; // ISR: revalidate every 60 seconds

async function getHomepageData() {
  const supabase = await createClient();

  const [
    { data: featuredProducts },
    { data: trendingProducts },
    { data: promotions },
  ] = await Promise.all([
    supabase
      .from('products')
      .select('id, name, slug, price, compare_price, thumbnail, images, category, is_trending, is_bestseller, is_premium, stock_qty, low_stock_threshold')
      .eq('is_featured', true)
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .limit(8),
    supabase
      .from('products')
      .select('id, name, slug, price, compare_price, thumbnail, images, category, is_trending, is_bestseller, is_premium, stock_qty, purchase_count')
      .eq('is_active', true)
      .order('purchase_count', { ascending: false })
      .limit(12),
    supabase
      .from('promotions')
      .select('*')
      .eq('is_active', true)
      .in('display_type', ['banner', 'notification_bar'])
      .or('scheduled_at.is.null,scheduled_at.lte.' + new Date().toISOString())
      .or('expires_at.is.null,expires_at.gt.' + new Date().toISOString())
      .order('priority', { ascending: false })
      .limit(3),
  ]);

  return {
    featuredProducts: featuredProducts || [],
    trendingProducts: trendingProducts || [],
    promotions: promotions || [],
  };
}

export default async function HomePage() {
  const { featuredProducts, trendingProducts, promotions } = await getHomepageData();

  const bannerPromotion = promotions.find((p) => p.display_type === 'banner');
  const notificationPromotion = promotions.find((p) => p.display_type === 'notification_bar');

  return (
    <>
      <Navbar />
      
      {/* Notification bar */}
      {notificationPromotion && (
        <div className="text-center py-2 text-xs tracking-[0.2em] uppercase" 
             style={{ background: 'var(--gold)', color: '#000' }}>
          {notificationPromotion.title}
          {notificationPromotion.button_url && notificationPromotion.button_label && (
            <a href={notificationPromotion.button_url} className="ml-3 underline font-semibold">
              {notificationPromotion.button_label}
            </a>
          )}
        </div>
      )}

      <main>
        {/* Hero */}
        <HeroSection />

        {/* Category Grid */}
        <section className="py-20 px-4 md:px-8 lg:px-16">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <p className="section-subtitle mb-3">Collections</p>
              <h2 className="section-title">Shop by Category</h2>
            </div>
            <CategoryGrid />
          </div>
        </section>

        {/* Featured Products */}
        <section className="py-20 px-4 md:px-8 lg:px-16" style={{ background: 'var(--bg-secondary)' }}>
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <p className="section-subtitle mb-3">Curated for You</p>
              <h2 className="section-title">Featured Pieces</h2>
            </div>
            <Suspense fallback={<div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {Array(8).fill(0).map((_, i) => <ProductSkeleton key={i} />)}
            </div>}>
              <FeaturedProducts products={featuredProducts} />
            </Suspense>
          </div>
        </section>

        {/* Banner Promotion */}
        {bannerPromotion && <PromotionBanner promotion={bannerPromotion} />}

        {/* Trending / Best Sellers */}
        <section className="py-20 px-4 md:px-8 lg:px-16">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <p className="section-subtitle mb-3">What&apos;s Hot</p>
              <h2 className="section-title">Trending Now</h2>
            </div>
            <TrendingSlider products={trendingProducts} />
          </div>
        </section>

        {/* Brand Story teaser */}
        <section className="py-24 px-4 md:px-8 lg:px-16 text-center" 
                 style={{ background: 'var(--bg-secondary)' }}>
          <div className="max-w-2xl mx-auto">
            <p className="section-subtitle mb-4">Our Story</p>
            <h2 className="section-title mb-6">Where Elegance Meets Every Step</h2>
            <div className="divider-gold mb-8" />
            <p className="text-sm leading-8 tracking-wide" style={{ color: 'var(--text-secondary)' }}>
              Tote & Tread was born from a passion for timeless craftsmanship and 
              modern luxury. Every piece in our collection is selected to elevate 
              your presence — whether you are stepping into a boardroom or setting 
              out on an adventure.
            </p>
            <a href="/about" className="btn-outline-gold inline-block mt-8">
              Discover Our Story
            </a>
          </div>
        </section>
      </main>

      <Footer />
      
      {/* WhatsApp floating button */}
      <WhatsAppButton phoneNumber={process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || ''} />
      
      {/* Exit intent popup */}
      <ExitIntentPopup />
    </>
  );
}
