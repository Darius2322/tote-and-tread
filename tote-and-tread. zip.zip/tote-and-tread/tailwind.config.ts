import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{js,ts,jsx,tsx,mdx}', './components/**/*.{js,ts,jsx,tsx,mdx}'],
  darkMode: ['class', '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        gold: {
          DEFAULT: '#C9A84C',
          light: '#E4C97E',
          dark: '#A07830',
          50: '#FDF9EE',
          100: '#F9EFCC',
          200: '#F2DC93',
          300: '#E8C55A',
          400: '#E4C97E',
          500: '#C9A84C',
          600: '#A07830',
          700: '#7A5920',
          800: '#573E16',
          900: '#3A280D',
        },
        luxury: {
          black: '#0A0A0A',
          charcoal: '#1A1A1A',
          dark: '#2A2A2A',
          gray: '#555555',
          light: '#AAAAAA',
          cream: '#F5F5F0',
        },
      },
      fontFamily: {
        display: ['Cormorant Garamond', 'Georgia', 'serif'],
        body: ['Montserrat', 'Helvetica Neue', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.6s ease forwards',
        'fade-up': 'fadeUp 0.6s ease forwards',
        'fade-down': 'fadeDown 0.4s ease forwards',
        'slide-left': 'slideLeft 0.5s ease forwards',
        'slide-right': 'slideRight 0.5s ease forwards',
        'scale-in': 'scaleIn 0.4s ease forwards',
        'shimmer': 'shimmer 2s infinite linear',
        'pulse-gold': 'pulseGold 2s ease infinite',
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: { from: { opacity: '0' }, to: { opacity: '1' } },
        fadeUp: { from: { opacity: '0', transform: 'translateY(20px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        fadeDown: { from: { opacity: '0', transform: 'translateY(-20px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        slideLeft: { from: { opacity: '0', transform: 'translateX(20px)' }, to: { opacity: '1', transform: 'translateX(0)' } },
        slideRight: { from: { opacity: '0', transform: 'translateX(-20px)' }, to: { opacity: '1', transform: 'translateX(0)' } },
        scaleIn: { from: { opacity: '0', transform: 'scale(0.95)' }, to: { opacity: '1', transform: 'scale(1)' } },
        shimmer: { '0%': { backgroundPosition: '200% 0' }, '100%': { backgroundPosition: '-200% 0' } },
        pulseGold: {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(201, 168, 76, 0.4)' },
          '50%': { boxShadow: '0 0 0 10px rgba(201, 168, 76, 0)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-8px)' },
        },
      },
      backgroundImage: {
        'gold-gradient': 'linear-gradient(135deg, #A07830, #C9A84C, #E4C97E)',
        'gold-gradient-h': 'linear-gradient(90deg, #A07830, #C9A84C, #E4C97E)',
        'dark-gradient': 'linear-gradient(180deg, #0A0A0A, #1A1A1A)',
        'hero-gradient': 'linear-gradient(135deg, rgba(10,10,10,0.95) 0%, rgba(10,10,10,0.7) 100%)',
      },
      boxShadow: {
        'gold': '0 0 30px rgba(201, 168, 76, 0.15)',
        'gold-lg': '0 0 50px rgba(201, 168, 76, 0.25)',
        'luxury': '0 20px 60px rgba(0, 0, 0, 0.5)',
        'card': '0 4px 20px rgba(0, 0, 0, 0.3)',
      },
    },
  },
  plugins: [],
};

export default config;
