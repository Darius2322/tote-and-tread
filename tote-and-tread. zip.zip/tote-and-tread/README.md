# Tote & Tread — Production-Ready Luxury E-Commerce

> "Step Into Style. Carry Confidence."

A fully production-ready luxury e-commerce platform for premium bags and footwear.

---

## ⚡ Quick Start (5 Steps)

### 1. Clone & Install
```bash
git clone https://github.com/yourusername/tote-and-tread.git
cd tote-and-tread
npm install
```

### 2. Supabase Setup
1. Create a free project at [supabase.com](https://supabase.com)
2. Go to **SQL Editor** → paste the full contents of `supabase/schema.sql` → Run
3. Go to **Storage** → create a new bucket called `tote-tread-assets` (set to Public)
4. In **Storage** policies, allow authenticated uploads

### 3. Environment Variables
```bash
cp .env.example .env.local
```
Fill in your values in `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_SITE_URL=https://yourdomain.com
NEXT_PUBLIC_WHATSAPP_NUMBER=+254700000000
JWT_SECRET=your-64-char-secret-here
```

### 4. Create Admin User
1. Register a new account at `/auth/register`
2. In **Supabase Dashboard → Table Editor → profiles**, find your user row
3. Change `role` from `customer` to `admin`
4. Now access `/admin/dashboard`

### 5. Run Locally
```bash
npm run dev
# Open http://localhost:3000
```

---

## 🚀 Deploy to Vercel

```bash
npm install -g vercel
vercel
```

Add all your `.env.local` variables in Vercel's **Project Settings → Environment Variables**.

---

## 🏗️ Architecture

```
tote-and-tread/
├── app/                    # Next.js App Router pages
│   ├── page.tsx            # Homepage
│   ├── about/              # About page
│   ├── gallery/            # Gallery page
│   ├── auth/               # Login, Register, Reset Password
│   ├── shop/               # Products, Cart, Checkout
│   ├── user/               # Dashboard, Orders, Wishlist, Notifications, Receipts
│   └── admin/              # Admin panel (protected)
├── components/             # Reusable React components
│   ├── layout/             # Header, Footer, WhatsApp button
│   ├── home/               # Hero, Categories, Featured, Trending
│   ├── shop/               # ProductCard, ProductDetail, Cart, Gallery
│   ├── admin/              # AdminNav, Forms, Tables
│   └── user/               # Receipt download
├── lib/                    # Utilities
│   ├── supabase/           # Client & Server Supabase clients
│   ├── validation.ts       # Zod schemas (XSS/injection protection)
│   ├── whatsapp.ts         # WhatsApp order generator
│   └── api-helpers.ts      # Auth guards, error handlers
├── types/                  # TypeScript types (auto-generated from DB)
├── supabase/
│   └── schema.sql          # Full database schema with RLS
├── public/
│   ├── manifest.json       # PWA manifest
│   ├── sw.js               # Service Worker
│   └── robots.txt
├── middleware.ts            # Rate limiting, auth, HTTPS enforcement
└── next.config.js          # Security headers, CSP, HSTS
```

---

## 🔐 Security Features

| Feature | Implementation |
|---------|---------------|
| **HTTPS Enforcement** | `middleware.ts` — forces HTTPS in production |
| **Security Headers** | `next.config.js` — HSTS, CSP, X-Frame-Options, XSS protection |
| **Rate Limiting** | `middleware.ts` — 100 req/min general, 10 req/min auth |
| **Input Validation** | `lib/validation.ts` — Zod schemas on all forms |
| **XSS Protection** | `sanitizeText()` utility + Content Security Policy |
| **SQL Injection** | Supabase parameterized queries (never raw SQL) |
| **CSRF Protection** | `sameSite: 'lax'` cookies + Next.js Server Actions |
| **Row Level Security** | Full RLS policies on all Supabase tables |
| **Role-Based Access** | `admin` / `customer` roles enforced in middleware + DB |
| **Auth Route Protection** | Middleware redirects unauthenticated users |
| **Secure Cookies** | `httpOnly: true`, `secure: true` in production |
| **Password Requirements** | Min 8 chars, uppercase, lowercase, number |
| **Error Masking** | Generic error messages prevent user enumeration |
| **Image Validation** | File type + size validation before upload |

---

## 📱 PWA Features

- Installable on iOS and Android
- Offline support via Service Worker
- Push notification support
- App icons for all sizes
- Custom splash screen

To generate proper icons, run:
```bash
npx pwa-asset-generator logo.png ./public/icons
```

---

## 🗄️ Database Tables

| Table | Purpose |
|-------|---------|
| `profiles` | User accounts (extends Supabase auth) |
| `categories` | Product categories |
| `products` | Product catalog with search indexing |
| `reviews` | Product reviews with approval system |
| `wishlists` | Saved products per user |
| `cart_items` | Shopping cart |
| `orders` | Order records |
| `order_items` | Line items per order |
| `receipts` | Receipt records with PDF support |
| `notifications` | User notifications |
| `promotions` | Banners, popups, notices |
| `gallery` | Lifestyle image gallery |
| `analytics_events` | Event tracking |
| `site_settings` | Key-value store for site config |

---

## 🛒 Checkout Flow (WhatsApp)

1. User adds items to cart
2. Clicks "Checkout via WhatsApp"
3. App generates a formatted WhatsApp message with full order details
4. User is redirected to WhatsApp with the pre-filled message
5. Admin receives and confirms via WhatsApp

---

## 🔮 Future Expansion (Already Architected)

- **M-Pesa / Stripe / PayPal** — Payment hooks ready in `orders` table
- **Delivery Tracking** — `orders.status` field supports full tracking states
- **Email Notifications** — Add Resend/Nodemailer to auth events
- **AI Search** — Replace current search with OpenAI embeddings
- **Multi-vendor** — Add `vendor_id` to products table
- **Native App** — React Native with shared Supabase backend
- **Loyalty Points** — Add `points` column to profiles

---

## 📄 License

Private & Proprietary — Tote & Tread © 2024
