'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { createClient } from '@/lib/supabase/client';
import { productSchema, type ProductInput } from '@/lib/validation';
import toast from 'react-hot-toast';
import { Upload, X } from 'lucide-react';

export default function ProductForm({ categories, product }: { categories: any[]; product?: any }) {
  const [images, setImages] = useState<string[]>(product?.images || []);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  const { register, handleSubmit, formState: { errors } } = useForm<ProductInput>({
    resolver: zodResolver(productSchema),
    defaultValues: product ? {
      name: product.name, description: product.description, price: product.price,
      compare_at_price: product.compare_at_price, category_id: product.category_id,
      stock_quantity: product.stock_quantity, badge: product.badge,
      is_active: product.is_active, is_featured: product.is_featured,
    } : { is_active: true, is_featured: false, stock_quantity: 0, low_stock_threshold: 5 },
  });

  async function uploadImage(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) { toast.error('Only JPEG, PNG, WebP allowed'); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error('Max file size is 5MB'); return; }
    setUploading(true);
    try {
      const fileName = `products/${Date.now()}-${Math.random().toString(36).slice(2)}.${file.type.split('/')[1]}`;
      const { data, error } = await supabase.storage.from(process.env.NEXT_PUBLIC_STORAGE_BUCKET || 'tote-tread-assets').upload(fileName, file, { cacheControl: '3600', upsert: false });
      if (error) throw error;
      const { data: urlData } = supabase.storage.from(process.env.NEXT_PUBLIC_STORAGE_BUCKET || 'tote-tread-assets').getPublicUrl(data.path);
      setImages(prev => [...prev, urlData.publicUrl]);
      toast.success('Image uploaded');
    } catch { toast.error('Upload failed'); }
    finally { setUploading(false); }
  }

  // Slug generator
  function toSlug(name: string) {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  }

  async function onSubmit(data: ProductInput) {
    setSaving(true);
    try {
      const payload = { ...data, images, slug: product?.slug || toSlug(data.name) };
      if (product) {
        const { error } = await supabase.from('products').update(payload).eq('id', product.id);
        if (error) throw error;
        toast.success('Product updated');
      } else {
        const { error } = await supabase.from('products').insert(payload);
        if (error) throw error;
        toast.success('Product created');
      }
      router.push('/admin/products');
      router.refresh();
    } catch (err: any) {
      toast.error(err.message || 'Save failed');
    } finally { setSaving(false); }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="max-w-3xl space-y-8">
      <div className="card-luxury p-8">
        <h2 className="font-display text-xl text-luxury-cream mb-6">Product Info</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="md:col-span-2">
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Product Name *</label>
            <input {...register('name')} className="input-luxury" placeholder="e.g. Milano Leather Tote" />
            {errors.name && <p className="mt-1 text-xs text-red-400">{errors.name.message}</p>}
          </div>
          <div className="md:col-span-2">
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Description</label>
            <textarea {...register('description')} rows={4} className="input-luxury resize-none pt-3" placeholder="Product description..." />
          </div>
          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Price (KSh) *</label>
            <input {...register('price', { valueAsNumber: true })} type="number" step="0.01" min="0" className="input-luxury" placeholder="0.00" />
            {errors.price && <p className="mt-1 text-xs text-red-400">{errors.price.message}</p>}
          </div>
          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Compare Price (KSh)</label>
            <input {...register('compare_at_price', { valueAsNumber: true, setValueAs: v => v === '' ? undefined : Number(v) })} type="number" step="0.01" min="0" className="input-luxury" placeholder="Original price" />
          </div>
          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Category</label>
            <select {...register('category_id')} className="w-full bg-transparent border-b-2 border-gold/30 py-3 text-luxury-cream font-body text-sm focus:outline-none focus:border-gold">
              <option value="">No Category</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Badge</label>
            <select {...register('badge')} className="w-full bg-transparent border-b-2 border-gold/30 py-3 text-luxury-cream font-body text-sm focus:outline-none focus:border-gold">
              <option value="">No Badge</option>
              {['trending','best_seller','premium','new','sale'].map(b => <option key={b} value={b}>{b.replace('_',' ')}</option>)}
            </select>
          </div>
          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Stock Quantity *</label>
            <input {...register('stock_quantity', { valueAsNumber: true })} type="number" min="0" className="input-luxury" placeholder="0" />
          </div>
          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Low Stock Alert At</label>
            <input {...register('low_stock_threshold', { valueAsNumber: true })} type="number" min="0" className="input-luxury" placeholder="5" />
          </div>
        </div>
        <div className="flex gap-6 mt-6">
          <label className="flex items-center gap-2 cursor-pointer">
            <input {...register('is_active')} type="checkbox" className="w-4 h-4 accent-yellow-500" />
            <span className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light">Active</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input {...register('is_featured')} type="checkbox" className="w-4 h-4 accent-yellow-500" />
            <span className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light">Featured</span>
          </label>
        </div>
      </div>

      {/* Images */}
      <div className="card-luxury p-8">
        <h2 className="font-display text-xl text-luxury-cream mb-6">Product Images</h2>
        <div className="grid grid-cols-4 gap-3 mb-4">
          {images.map((url, i) => (
            <div key={i} className="relative aspect-square bg-luxury-dark overflow-hidden group">
              <img src={url} alt="" className="w-full h-full object-cover" />
              <button type="button" onClick={() => setImages(prev => prev.filter((_, j) => j !== i))} className="absolute top-1 right-1 bg-black/70 text-white hover:text-red-400 p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <X size={12} />
              </button>
            </div>
          ))}
          <label className={`aspect-square border-2 border-dashed border-gold/30 flex flex-col items-center justify-center cursor-pointer hover:border-gold transition-colors ${uploading ? 'opacity-50 cursor-wait' : ''}`}>
            <Upload size={20} className="text-luxury-light mb-1" />
            <span className="font-body text-[10px] text-luxury-light">{uploading ? 'Uploading...' : 'Upload'}</span>
            <input type="file" accept="image/jpeg,image/png,image/webp" onChange={uploadImage} disabled={uploading} className="hidden" />
          </label>
        </div>
        <p className="font-body text-[10px] text-luxury-light">Max 5MB per image. JPEG, PNG, or WebP.</p>
      </div>

      <div className="flex gap-4">
        <button type="submit" disabled={saving} className="btn-luxury flex-1">{saving ? 'Saving...' : product ? 'Update Product' : 'Create Product'}</button>
        <button type="button" onClick={() => router.push('/admin/products')} className="px-8 border border-gold/30 text-luxury-light hover:border-gold font-body text-xs font-semibold tracking-widest uppercase transition-colors">Cancel</button>
      </div>
    </form>
  );
}
