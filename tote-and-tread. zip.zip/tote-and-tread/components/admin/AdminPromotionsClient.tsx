'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { createClient } from '@/lib/supabase/client';
import { Plus, Edit, Trash2, X, Check } from 'lucide-react';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

interface Promo { id: string; title: string; description: string | null; display_type: string; is_active: boolean; discount_percent: number | null; ends_at: string | null; button_text: string | null; button_url: string | null; }

export default function AdminPromotionsClient({ initialPromos }: { initialPromos: Promo[] }) {
  const [promos, setPromos] = useState(initialPromos);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Promo | null>(null);
  const [form, setForm] = useState({ title: '', description: '', display_type: 'banner', is_active: true, discount_percent: '', ends_at: '', button_text: '', button_url: '' });
  const supabase = createClient();

  function openNew() { setForm({ title: '', description: '', display_type: 'banner', is_active: true, discount_percent: '', ends_at: '', button_text: '', button_url: '' }); setEditing(null); setShowForm(true); }
  function openEdit(p: Promo) { setForm({ title: p.title, description: p.description || '', display_type: p.display_type, is_active: p.is_active, discount_percent: p.discount_percent?.toString() || '', ends_at: p.ends_at ? p.ends_at.slice(0, 16) : '', button_text: p.button_text || '', button_url: p.button_url || '' }); setEditing(p); setShowForm(true); }

  async function save() {
    const payload = { ...form, discount_percent: form.discount_percent ? parseInt(form.discount_percent) : null, ends_at: form.ends_at || null };
    if (editing) {
      const { error } = await supabase.from('promotions').update(payload).eq('id', editing.id);
      if (error) { toast.error('Update failed'); return; }
      setPromos(prev => prev.map(p => p.id === editing.id ? { ...p, ...payload } as any : p));
      toast.success('Promotion updated');
    } else {
      const { data, error } = await supabase.from('promotions').insert(payload).select().single();
      if (error) { toast.error('Create failed'); return; }
      setPromos(prev => [data, ...prev]);
      toast.success('Promotion created');
    }
    setShowForm(false);
  }

  async function deletePromo(id: string) {
    if (!confirm('Delete this promotion?')) return;
    await supabase.from('promotions').delete().eq('id', id);
    setPromos(prev => prev.filter(p => p.id !== id));
    toast.success('Deleted');
  }

  async function toggleActive(p: Promo) {
    await supabase.from('promotions').update({ is_active: !p.is_active }).eq('id', p.id);
    setPromos(prev => prev.map(x => x.id === p.id ? { ...x, is_active: !x.is_active } : x));
  }

  return (
    <div>
      <button onClick={openNew} className="btn-luxury flex items-center gap-2 text-xs mb-6"><Plus size={14} /> New Promotion</button>

      <div className="grid md:grid-cols-2 gap-4">
        {promos.map(p => (
          <div key={p.id} className={`card-luxury p-5 ${!p.is_active ? 'opacity-60' : ''}`}>
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <h3 className="font-body font-semibold text-sm text-luxury-cream">{p.title}</h3>
                <span className="font-body text-[10px] tracking-widest uppercase text-gold">{p.display_type}</span>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => toggleActive(p)} className={`p-1.5 transition-colors ${p.is_active ? 'text-green-400 hover:text-green-300' : 'text-luxury-light hover:text-green-400'}`}><Check size={14} /></button>
                <button onClick={() => openEdit(p)} className="p-1.5 text-luxury-light hover:text-gold transition-colors"><Edit size={14} /></button>
                <button onClick={() => deletePromo(p.id)} className="p-1.5 text-luxury-light hover:text-red-400 transition-colors"><Trash2 size={14} /></button>
              </div>
            </div>
            {p.description && <p className="font-body text-xs text-luxury-light mb-2">{p.description}</p>}
            {p.discount_percent && <p className="font-body text-xs text-gold">Discount: {p.discount_percent}%</p>}
            {p.ends_at && <p className="font-body text-xs text-luxury-light mt-1">Ends: {format(new Date(p.ends_at), 'MMM d, yyyy')}</p>}
          </div>
        ))}
        {!promos.length && <p className="font-body text-sm text-luxury-light col-span-2 text-center py-12">No promotions yet</p>}
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4" onClick={e => { if (e.target === e.currentTarget) setShowForm(false); }}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} className="bg-luxury-charcoal border border-gold/20 w-full max-w-lg p-8 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-display text-2xl text-luxury-cream">{editing ? 'Edit' : 'New'} Promotion</h2>
                <button onClick={() => setShowForm(false)} className="text-luxury-light hover:text-gold"><X size={18} /></button>
              </div>
              <div className="space-y-5">
                {[['title', 'Title *', 'text'], ['description', 'Description', 'text'], ['button_text', 'Button Text', 'text'], ['button_url', 'Button URL', 'url'], ['ends_at', 'End Date', 'datetime-local'], ['discount_percent', 'Discount %', 'number']].map(([field, label, type]) => (
                  <div key={field}>
                    <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">{label}</label>
                    <input type={type} value={(form as any)[field]} onChange={e => setForm(f => ({ ...f, [field]: e.target.value }))} className="input-luxury" />
                  </div>
                ))}
                <div>
                  <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Display Type</label>
                  <select value={form.display_type} onChange={e => setForm(f => ({ ...f, display_type: e.target.value }))} className="w-full bg-transparent border-b-2 border-gold/30 py-3 text-luxury-cream font-body text-sm focus:outline-none focus:border-gold">
                    <option value="banner">Banner</option>
                    <option value="popup">Popup</option>
                    <option value="notification_bar">Notification Bar</option>
                  </select>
                </div>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" checked={form.is_active} onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))} className="w-4 h-4 accent-yellow-500" />
                  <span className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light">Active</span>
                </label>
                <button onClick={save} className="btn-luxury w-full">{editing ? 'Update' : 'Create'} Promotion</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
