'use client';
import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

const STATUSES = ['pending','confirmed','processing','shipped','delivered','cancelled','refunded'];
const STATUS_STYLES: Record<string, string> = {
  pending: 'text-yellow-400 bg-yellow-400/10',
  confirmed: 'text-blue-400 bg-blue-400/10',
  processing: 'text-purple-400 bg-purple-400/10',
  shipped: 'text-cyan-400 bg-cyan-400/10',
  delivered: 'text-green-400 bg-green-400/10',
  cancelled: 'text-red-400 bg-red-400/10',
  refunded: 'text-orange-400 bg-orange-400/10',
};

export default function AdminOrdersClient({ initialOrders }: { initialOrders: any[] }) {
  const [orders, setOrders] = useState(initialOrders);
  const [filter, setFilter] = useState('all');
  const supabase = createClient();

  async function updateStatus(orderId: string, status: string) {
    const { error } = await supabase.from('orders').update({ status }).eq('id', orderId);
    if (error) { toast.error('Failed to update'); return; }
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
    toast.success('Status updated');
  }

  const filtered = filter === 'all' ? orders : orders.filter(o => o.status === filter);

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-6">
        {['all', ...STATUSES].map(s => (
          <button key={s} onClick={() => setFilter(s)} className={`font-body text-xs font-semibold tracking-widest uppercase px-3 py-1.5 border transition-colors ${filter === s ? 'bg-gold text-black border-gold' : 'border-gold/30 text-luxury-light hover:border-gold'}`}>
            {s}
          </button>
        ))}
      </div>

      <div className="card-luxury overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-gold/10">
              <tr>
                {['Order', 'Customer', 'Items', 'Total', 'Date', 'Status', 'Action'].map(h => (
                  <th key={h} className="text-left px-4 py-3 font-body text-xs font-bold tracking-widest uppercase text-luxury-light">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(o => (
                <tr key={o.id} className="border-b border-gold/5 hover:bg-gold/5 transition-colors">
                  <td className="px-4 py-3 font-body text-xs font-bold text-gold">{o.order_number}</td>
                  <td className="px-4 py-3">
                    <p className="font-body text-xs text-luxury-cream">{(o.profiles as any)?.full_name || 'Guest'}</p>
                    <p className="font-body text-[10px] text-luxury-light">{(o.profiles as any)?.email}</p>
                  </td>
                  <td className="px-4 py-3 font-body text-xs text-luxury-light">{(o.order_items as any[])?.length || 0} items</td>
                  <td className="px-4 py-3 font-body text-xs font-bold text-gold">KSh {o.total?.toLocaleString()}</td>
                  <td className="px-4 py-3 font-body text-xs text-luxury-light">{format(new Date(o.created_at), 'MMM d, yy')}</td>
                  <td className="px-4 py-3">
                    <span className={`font-body text-[10px] font-bold tracking-widest uppercase px-2 py-1 ${STATUS_STYLES[o.status] || ''}`}>{o.status}</span>
                  </td>
                  <td className="px-4 py-3">
                    <select value={o.status} onChange={e => updateStatus(o.id, e.target.value)} className="bg-luxury-dark border border-gold/30 text-luxury-light font-body text-xs px-2 py-1 focus:outline-none focus:border-gold">
                      {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!filtered.length && <p className="text-center py-12 font-body text-sm text-luxury-light">No orders found</p>}
        </div>
      </div>
    </div>
  );
}
