'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Package, Users, ShoppingCart, TrendingUp, Megaphone, Image, Settings, LogOut } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';

const navItems = [
  { href: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/admin/products', icon: Package, label: 'Products' },
  { href: '/admin/orders', icon: ShoppingCart, label: 'Orders' },
  { href: '/admin/users', icon: Users, label: 'Users' },
  { href: '/admin/analytics', icon: TrendingUp, label: 'Analytics' },
  { href: '/admin/promotions', icon: Megaphone, label: 'Promotions' },
  { href: '/admin/gallery', icon: Image, label: 'Gallery' },
  { href: '/admin/settings', icon: Settings, label: 'Settings' },
];

export default function AdminNav() {
  const pathname = usePathname();
  const router = useRouter();

  async function signOut() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push('/');
  }

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-luxury-charcoal border-r border-gold/10 flex flex-col z-40">
      <div className="p-6 border-b border-gold/10">
        <Link href="/" className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gold-gradient flex items-center justify-center">
            <span className="font-display font-bold text-black text-sm">T</span>
          </div>
          <div>
            <p className="font-display text-sm font-bold text-gold-gradient">Tote & Tread</p>
            <p className="font-body text-[10px] text-luxury-light tracking-widest uppercase">Admin Panel</p>
          </div>
        </Link>
      </div>

      <nav className="flex-1 py-6 overflow-y-auto">
        {navItems.map(({ href, icon: Icon, label }) => (
          <Link
            key={href}
            href={href}
            className={`flex items-center gap-3 px-6 py-3 font-body text-xs font-semibold tracking-widest uppercase transition-all duration-200 ${
              pathname.startsWith(href)
                ? 'text-gold bg-gold/10 border-r-2 border-gold'
                : 'text-luxury-light hover:text-gold hover:bg-gold/5'
            }`}
          >
            <Icon size={16} />
            {label}
          </Link>
        ))}
      </nav>

      <div className="p-6 border-t border-gold/10">
        <button onClick={signOut} className="flex items-center gap-3 font-body text-xs font-semibold tracking-widest uppercase text-luxury-light hover:text-red-400 transition-colors w-full">
          <LogOut size={16} />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
