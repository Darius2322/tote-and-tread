'use client';
import { Download } from 'lucide-react';

export default function ReceiptDownload({ receipt }: { receipt: any }) {
  async function downloadPDF() {
    const { default: jsPDF } = await import('jspdf');
    const { default: autoTable } = await import('jspdf-autotable');

    const doc = new jsPDF();
    const order = receipt.orders;

    // Header
    doc.setFillColor(10, 10, 10);
    doc.rect(0, 0, 210, 40, 'F');
    doc.setTextColor(201, 168, 76);
    doc.setFontSize(22);
    doc.text('TOTE & TREAD', 14, 18);
    doc.setFontSize(9);
    doc.setTextColor(170, 170, 170);
    doc.text('Step Into Style. Carry Confidence.', 14, 26);
    doc.text('RECEIPT', 170, 18, { align: 'right' });

    // Receipt info
    doc.setTextColor(10, 10, 10);
    doc.setFontSize(10);
    doc.text(`Receipt #: ${receipt.receipt_number}`, 14, 55);
    doc.text(`Order #: ${order?.order_number || '—'}`, 14, 63);
    doc.text(`Date: ${new Date(receipt.generated_at).toLocaleDateString('en-KE', { year: 'numeric', month: 'long', day: 'numeric' })}`, 14, 71);

    // Items table
    const items = order?.order_items || [];
    autoTable(doc, {
      startY: 85,
      head: [['Item', 'Qty', 'Unit Price', 'Subtotal']],
      body: items.map((i: any) => [
        i.product_name,
        i.quantity,
        `KSh ${Number(i.price).toLocaleString()}`,
        `KSh ${Number(i.subtotal || i.price * i.quantity).toLocaleString()}`,
      ]),
      foot: [['', '', 'TOTAL', `KSh ${Number(order?.total).toLocaleString()}`]],
      headStyles: { fillColor: [10, 10, 10], textColor: [201, 168, 76], fontStyle: 'bold' },
      footStyles: { fillColor: [245, 245, 240], textColor: [10, 10, 10], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 248, 245] },
    });

    // Footer
    const finalY = (doc as any).lastAutoTable.finalY + 15;
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text('Thank you for shopping with Tote & Tread.', 105, finalY, { align: 'center' });
    doc.text('For support, contact us via WhatsApp or email hello@toteandtread.com', 105, finalY + 6, { align: 'center' });

    doc.save(`TT-Receipt-${receipt.receipt_number}.pdf`);
  }

  return (
    <button onClick={downloadPDF} className="flex items-center gap-2 btn-luxury text-xs px-4 py-2">
      <Download size={12} /> Download PDF
    </button>
  );
}
