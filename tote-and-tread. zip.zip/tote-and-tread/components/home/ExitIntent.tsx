'use client';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

export default function ExitIntent({ promo }: { promo: any }) {
  const [show, setShow] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const key = 'exit_popup_shown';
    if (sessionStorage.getItem(key)) return;
    const handle = (e: MouseEvent) => {
      if (e.clientY <= 10 && !dismissed) {
        setShow(true);
        sessionStorage.setItem(key, '1');
      }
    };
    document.addEventListener('mouseleave', handle);
    return () => document.removeEventListener('mouseleave', handle);
  }, [dismissed]);

  const close = () => { setShow(false); setDismissed(true); };

  if (!promo && !show) return null;

  const title = promo?.title || 'Wait! Before You Go...';
  const desc = promo?.description || 'Get 10% off your first order when you sign up today.';

  return (
    <AnimatePresence>
      {show && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[200] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={(e) => { if (e.target === e.currentTarget) close(); }}>
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="relative bg-luxury-charcoal border border-gold/30 max-w-md w-full p-10 text-center shadow-gold-lg">
            <button onClick={close} className="absolute top-4 right-4 text-luxury-light hover:text-gold"><X size={18} /></button>
            <div className="w-16 h-16 rounded-full bg-gold-gradient flex items-center justify-center mx-auto mb-6">
              <span className="font-display font-bold text-2xl text-black">T</span>
            </div>
            <h3 className="font-display text-3xl text-gold mb-3">{title}</h3>
            <p className="font-body text-sm text-luxury-light mb-6">{desc}</p>
            <a href="/auth/register" onClick={close} className="btn-luxury inline-block w-full mb-3">Claim Offer</a>
            <button onClick={close} className="font-body text-xs text-luxury-light hover:text-gold transition-colors">No thanks, I'll pay full price</button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
