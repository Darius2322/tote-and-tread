'use client';
import Link from 'next/link';
import { motion } from 'framer-motion';

const fallbackImages: Record<string, string> = {
  handbags: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&q=80',
  'travel-bags': 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&q=80',
  sneakers: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80',
  'formal-shoes': 'https://images.unsplash.com/photo-1614252369475-531eba835eb1?w=800&q=80',
};

export default function CategorySection({ categories }: { categories: any[] }) {
  const cats = categories.length
    ? categories
    : [
        { name: 'Handbags', slug: 'handbags' },
        { name: 'Travel Bags', slug: 'travel-bags' },
        { name: 'Sneakers', slug: 'sneakers' },
        { name: 'Formal Shoes', slug: 'formal-shoes' },
      ];

  return (
    <section className="py-24 bg-luxury-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="font-body text-xs tracking-[0.4em] uppercase text-gold font-semibold">Collections</span>
          <h2 className="font-display text-5xl md:text-6xl font-light mt-2 text-luxury-cream">
            Shop by <span className="text-gold-gradient italic">Category</span>
          </h2>
          <div className="divider-gold mt-6" />
        </motion.div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {cats.map((cat, i) => (
            <motion.div
              key={cat.slug}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Link href={`/shop/products?category=${cat.slug}`} className="group block relative overflow-hidden aspect-[3/4]">
                <img
                  src={cat.image_url || fallbackImages[cat.slug] || fallbackImages['handbags']}
                  alt={cat.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute inset-0 border border-transparent group-hover:border-gold/40 transition-colors duration-300" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="font-display text-2xl font-light text-white mb-1">{cat.name}</h3>
                  <span className="font-body text-xs tracking-widest text-gold uppercase opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    Shop Now →
                  </span>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
