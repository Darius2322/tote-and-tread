'use client';
import { motion } from 'framer-motion';
import ProductCard from '@/components/shop/ProductCard';

export default function TrendingSection({ products }: { products: any[] }) {
  if (!products.length) return null;
  return (
    <section className="py-24 bg-luxury-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <span className="font-body text-xs tracking-[0.4em] uppercase text-gold font-semibold">🔥 Hot Right Now</span>
          <h2 className="font-display text-5xl md:text-6xl font-light mt-2 text-luxury-cream">
            Trending <span className="text-gold-gradient italic">Now</span>
          </h2>
          <div className="divider-gold mt-6" />
        </motion.div>
        <div className="overflow-x-auto pb-4 -mx-4 px-4">
          <div className="flex gap-4 min-w-max md:min-w-0 md:grid md:grid-cols-4 lg:grid-cols-5">
            {products.map((product, i) => (
              <motion.div key={product.id} className="w-60 md:w-auto flex-shrink-0" initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}>
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
