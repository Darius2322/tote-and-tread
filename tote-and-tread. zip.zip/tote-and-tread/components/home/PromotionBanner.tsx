'use client';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { useState } from 'react';

export default function PromotionBanner({ promo }: { promo: any }) {
  const [closed, setClosed] = useState(false);
  if (closed || !promo) return null;
  return (
    <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="relative bg-luxury-charcoal border-y border-gold/30 py-6">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h3 className="font-display text-2xl text-gold">{promo.title}</h3>
        {promo.description && <p className="font-body text-sm text-luxury-light mt-1">{promo.description}</p>}
        {promo.button_text && promo.button_url && (
          <Link href={promo.button_url} className="inline-block mt-3 btn-luxury text-xs">{promo.button_text}</Link>
        )}
      </div>
      <button onClick={() => setClosed(true)} className="absolute top-3 right-4 text-luxury-light hover:text-gold"><X size={16} /></button>
    </motion.div>
  );
}
