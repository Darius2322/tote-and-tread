'use client';
import { motion } from 'framer-motion';
import ProductCard from '@/components/shop/ProductCard';

export default function FeaturedProducts({ products }: { products: any[] }) {
  if (!products.length) return null;
  return (
    <section className="py-24" style={{ background: 'var(--bg-secondary)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <span className="font-body text-xs tracking-[0.4em] uppercase text-gold font-semibold">Curated Selection</span>
          <h2 className="font-display text-5xl md:text-6xl font-light mt-2" style={{ color: 'var(--text-primary)' }}>
            Featured <span className="text-gold-gradient italic">Products</span>
          </h2>
          <div className="divider-gold mt-6" />
        </motion.div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {products.map((product, i) => (
            <motion.div key={product.id} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}>
              <ProductCard product={product} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
