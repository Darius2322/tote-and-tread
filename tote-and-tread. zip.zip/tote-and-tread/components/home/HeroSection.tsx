'use client';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-luxury-black">
      {/* Background */}
      <motion.div
        className="absolute inset-0 z-0"
        initial={{ scale: 1.1 }}
        animate={{ scale: 1 }}
        transition={{ duration: 8, ease: 'easeOut' }}
      >
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=1920&q=85')" }}
        />
        <div className="absolute inset-0 bg-hero-gradient" />
        <div className="absolute inset-0 bg-gradient-to-t from-luxury-black via-transparent to-transparent" />
      </motion.div>

      {/* Gold particle lines */}
      <div className="absolute inset-0 z-[1] overflow-hidden pointer-events-none">
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-px"
            style={{
              background: 'linear-gradient(90deg, transparent, rgba(201,168,76,0.4), transparent)',
              width: '60%',
              top: `${30 + i * 20}%`,
              left: '20%',
            }}
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{ scaleX: 1, opacity: 1 }}
            transition={{ delay: 1 + i * 0.3, duration: 1.5, ease: 'easeOut' }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="mb-4"
        >
          <span className="font-body text-xs tracking-[0.4em] uppercase text-gold font-semibold">
            ✦ Premium Luxury Collection ✦
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="font-display text-6xl md:text-8xl lg:text-[9rem] font-light leading-none mb-6"
          style={{ color: '#F5F5F0' }}
        >
          Tote &<br />
          <span className="text-gold-gradient italic">Tread</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="font-display text-xl md:text-2xl italic text-luxury-light mb-10"
        >
          "Step Into Style. Carry Confidence."
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Link href="/shop/products" className="btn-luxury relative z-10 min-w-[180px] text-center">
            Shop Now
          </Link>
          <Link
            href="/about"
            className="px-8 py-3 border border-gold/40 text-gold hover:bg-gold/10 transition-all font-body text-sm font-semibold tracking-widest uppercase min-w-[180px] text-center"
          >
            Our Story
          </Link>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
      >
        <span className="font-body text-[10px] tracking-widest text-luxury-light uppercase">Scroll</span>
        <motion.div
          className="w-px h-12 bg-gold-gradient"
          animate={{ scaleY: [0, 1, 0], originY: 'top' }}
          transition={{ duration: 1.5, repeat: Infinity }}
        />
      </motion.div>
    </section>
  );
}
