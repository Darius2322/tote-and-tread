import Link from 'next/link';
import { Instagram, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-luxury-black border-t border-gold/10">
      {/* Gold divider */}
      <div className="h-px bg-gold-gradient-h" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gold-gradient flex items-center justify-center">
                <span className="font-display font-bold text-xl text-black">T</span>
              </div>
              <span className="font-display text-2xl font-bold text-gold-gradient">Tote & Tread</span>
            </div>
            <p className="font-display text-lg italic text-luxury-light mb-2">
              "Step Into Style. Carry Confidence."
            </p>
            <p className="font-body text-xs text-luxury-light/60 max-w-xs leading-relaxed">
              Where elegance meets every step. Premium luxury bags and footwear crafted for the discerning individual.
            </p>
            <div className="flex items-center gap-4 mt-6">
              <a href="https://instagram.com/toteandtread" target="_blank" rel="noopener noreferrer"
                className="p-2 border border-gold/20 text-luxury-light hover:text-gold hover:border-gold transition-all">
                <Instagram size={16} />
              </a>
              <a href="https://facebook.com/toteandtread" target="_blank" rel="noopener noreferrer"
                className="p-2 border border-gold/20 text-luxury-light hover:text-gold hover:border-gold transition-all">
                <Facebook size={16} />
              </a>
              {/* TikTok icon */}
              <a href="https://tiktok.com/@toteandtread" target="_blank" rel="noopener noreferrer"
                className="p-2 border border-gold/20 text-luxury-light hover:text-gold hover:border-gold transition-all">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.69a8.17 8.17 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.12z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-body text-xs font-bold tracking-widest uppercase text-gold mb-6">Navigate</h4>
            <ul className="space-y-3">
              {[
                { href: '/', label: 'Home' },
                { href: '/shop/products', label: 'Shop' },
                { href: '/about', label: 'About' },
                { href: '/gallery', label: 'Gallery' },
                { href: '/contact', label: 'Contact' },
              ].map(link => (
                <li key={link.href}>
                  <Link href={link.href} className="font-body text-xs text-luxury-light hover:text-gold transition-colors tracking-wide">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer */}
          <div>
            <h4 className="font-body text-xs font-bold tracking-widest uppercase text-gold mb-6">Account</h4>
            <ul className="space-y-3">
              {[
                { href: '/auth/login', label: 'Sign In' },
                { href: '/auth/register', label: 'Create Account' },
                { href: '/user/orders', label: 'My Orders' },
                { href: '/user/wishlist', label: 'Wishlist' },
                { href: '/user/receipts', label: 'Receipts' },
              ].map(link => (
                <li key={link.href}>
                  <Link href={link.href} className="font-body text-xs text-luxury-light hover:text-gold transition-colors tracking-wide">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gold/10 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-body text-xs text-luxury-light/40 tracking-wide">
            © {new Date().getFullYear()} Tote & Tread. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link href="/privacy" className="font-body text-xs text-luxury-light/40 hover:text-gold transition-colors">Privacy Policy</Link>
            <Link href="/terms" className="font-body text-xs text-luxury-light/40 hover:text-gold transition-colors">Terms</Link>
            {/* Hidden admin link */}
            <Link href="/auth/login?admin=true" className="font-body text-[10px] text-luxury-light/20 hover:text-luxury-light/40 transition-colors">
              Admin Access
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
