'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ShoppingBag, Heart, User, Menu, X, Sun, Moon } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [cartCount, setCartCount] = useState(0);
  const [user, setUser] = useState<any>(null);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem('theme') as 'dark' | 'light' || 'dark';
    setTheme(saved);
    document.documentElement.setAttribute('data-theme', saved);
  }, []);

  useEffect(() => {
    const supabase = createClient();
    supabase.auth.getUser().then(({ data: { user } }) => setUser(user));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user || null);
      if (session?.user) fetchCartCount(supabase, session.user.id);
    });
    return () => subscription.unsubscribe();
  }, []);

  async function fetchCartCount(supabase: any, userId: string) {
    const { count } = await supabase
      .from('cart_items')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId);
    setCartCount(count || 0);
  }

  function toggleTheme() {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    localStorage.setItem('theme', next);
    document.documentElement.setAttribute('data-theme', next);
  }

  async function handleSearch(q: string) {
    setSearchQuery(q);
    if (q.length < 2) { setSearchResults([]); return; }
    const supabase = createClient();
    const { data } = await supabase
      .from('products')
      .select('id, name, slug, images, price')
      .ilike('name', `%${q}%`)
      .eq('is_active', true)
      .limit(6);
    setSearchResults(data || []);
  }

  const navLinks = [
    { href: '/', label: 'Home' },
    { href: '/shop/products', label: 'Shop' },
    { href: '/shop/products?category=handbags', label: 'Handbags' },
    { href: '/shop/products?category=footwear', label: 'Footwear' },
    { href: '/about', label: 'About' },
  ];

  return (
    <>
      {/* Announcement Bar */}
      <div className="announcement-bar text-black text-center text-xs py-2 px-4 font-body font-semibold tracking-widest uppercase">
        ✦ Free Delivery on Orders Over KSh 10,000 ✦ Step Into Style. Carry Confidence. ✦
      </div>

      <header
        className={`sticky top-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-luxury-black/95 backdrop-blur-md shadow-luxury border-b border-gold/10'
            : 'bg-luxury-black/80 backdrop-blur-sm'
        }`}
      >
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <Link href="/" className="flex-shrink-0 group">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-full bg-gold-gradient flex items-center justify-center">
                  <span className="font-display font-bold text-lg text-black">T</span>
                </div>
                <div>
                  <span className="font-display text-xl font-bold tracking-wider text-gold-gradient">
                    Tote & Tread
                  </span>
                </div>
              </div>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center space-x-8">
              {navLinks.map(link => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light hover:text-gold transition-colors duration-300 relative group"
                >
                  {link.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-px bg-gold-gradient transition-all duration-300 group-hover:w-full" />
                </Link>
              ))}
            </div>

            {/* Actions */}
            <div className="flex items-center space-x-3">
              {/* Search */}
              <button
                onClick={() => setSearchOpen(true)}
                className="p-2 text-luxury-light hover:text-gold transition-colors"
                aria-label="Search"
              >
                <Search size={18} />
              </button>

              {/* Theme toggle */}
              <button
                onClick={toggleTheme}
                className="p-2 text-luxury-light hover:text-gold transition-colors"
                aria-label="Toggle theme"
              >
                {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
              </button>

              {/* Wishlist */}
              {user && (
                <Link href="/user/wishlist" className="p-2 text-luxury-light hover:text-gold transition-colors" aria-label="Wishlist">
                  <Heart size={18} />
                </Link>
              )}

              {/* Cart */}
              <Link href="/shop/cart" className="p-2 text-luxury-light hover:text-gold transition-colors relative" aria-label="Cart">
                <ShoppingBag size={18} />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-gold text-black text-[10px] font-bold flex items-center justify-center">
                    {cartCount > 9 ? '9+' : cartCount}
                  </span>
                )}
              </Link>

              {/* User */}
              <Link
                href={user ? '/user/dashboard' : '/auth/login'}
                className="p-2 text-luxury-light hover:text-gold transition-colors"
                aria-label="Account"
              >
                <User size={18} />
              </Link>

              {/* Mobile menu */}
              <button
                className="lg:hidden p-2 text-luxury-light hover:text-gold"
                onClick={() => setMobileOpen(!mobileOpen)}
                aria-label="Menu"
              >
                {mobileOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </nav>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="lg:hidden overflow-hidden bg-luxury-charcoal border-t border-gold/10"
            >
              <div className="px-6 py-6 space-y-4">
                {navLinks.map(link => (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className="block font-body text-sm font-semibold tracking-widest uppercase text-luxury-light hover:text-gold transition-colors py-2 border-b border-gold/10"
                  >
                    {link.label}
                  </Link>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Search Modal */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md"
            onClick={(e) => { if (e.target === e.currentTarget) setSearchOpen(false); }}
          >
            <motion.div
              initial={{ y: -50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -50, opacity: 0 }}
              className="max-w-2xl mx-auto mt-20 px-4"
              ref={searchRef}
            >
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gold" size={20} />
                <input
                  autoFocus
                  type="search"
                  placeholder="Search bags, footwear..."
                  value={searchQuery}
                  onChange={e => handleSearch(e.target.value)}
                  className="w-full bg-luxury-charcoal border border-gold/30 rounded-none py-5 pl-12 pr-12 text-white font-body text-lg focus:outline-none focus:border-gold"
                />
                <button onClick={() => setSearchOpen(false)} className="absolute right-4 top-1/2 -translate-y-1/2 text-luxury-light hover:text-gold">
                  <X size={20} />
                </button>
              </div>

              {searchResults.length > 0 && (
                <div className="bg-luxury-charcoal border border-gold/20 border-t-0 max-h-80 overflow-y-auto">
                  {searchResults.map(product => (
                    <Link
                      key={product.id}
                      href={`/shop/products/${product.slug}`}
                      onClick={() => { setSearchOpen(false); setSearchQuery(''); setSearchResults([]); }}
                      className="flex items-center gap-4 px-4 py-3 hover:bg-luxury-dark transition-colors border-b border-gold/10"
                    >
                      {product.images?.[0] && (
                        <img src={product.images[0]} alt={product.name} className="w-12 h-12 object-cover" />
                      )}
                      <div>
                        <p className="text-white text-sm font-medium">{product.name}</p>
                        <p className="text-gold text-xs">KSh {product.price?.toLocaleString()}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
