'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { generateWhatsAppOrderMessage, getWhatsAppUrl } from '@/lib/whatsapp';
import toast from 'react-hot-toast';

export default function CartContent() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [checkingOut, setCheckingOut] = useState(false);
  const supabase = createClient();

  useEffect(() => { fetchCart(); }, []);

  async function fetchCart() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }
    const { data } = await supabase
      .from('cart_items')
      .select('*, products(id, name, slug, price, images, stock_quantity)')
      .eq('user_id', user.id);
    setItems(data || []);
    setLoading(false);
  }

  async function updateQty(id: string, qty: number, max: number) {
    if (qty < 1) return removeItem(id);
    if (qty > max) { toast.error(`Only ${max} in stock`); return; }
    await supabase.from('cart_items').update({ quantity: qty }).eq('id', id);
    setItems(prev => prev.map(i => i.id === id ? { ...i, quantity: qty } : i));
  }

  async function removeItem(id: string) {
    await supabase.from('cart_items').delete().eq('id', id);
    setItems(prev => prev.filter(i => i.id !== id));
    toast.success('Item removed');
  }

  async function handleCheckout() {
    setCheckingOut(true);
    const { data: { user } } = await supabase.auth.getUser();
    const { data: profile } = user ? await supabase.from('profiles').select('full_name, phone').eq('id', user!.id).single() : { data: null };
    const whatsappNum = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '+254700000000';
    const msg = generateWhatsAppOrderMessage({
      customerName: profile?.full_name || 'Customer',
      customerPhone: profile?.phone,
      items: items.map(i => ({ name: i.products.name, quantity: i.quantity, price: i.products.price, size: i.size, color: i.color })),
      total: subtotal,
    });
    window.open(getWhatsAppUrl(whatsappNum, msg), '_blank');
    setCheckingOut(false);
  }

  const subtotal = items.reduce((s, i) => s + (i.products?.price || 0) * i.quantity, 0);

  if (loading) return <div className="max-w-4xl mx-auto px-4 py-20 text-center"><div className="skeleton h-96" /></div>;

  if (!items.length) return (
    <div className="max-w-4xl mx-auto px-4 py-32 text-center">
      <ShoppingBag size={64} strokeWidth={1} className="mx-auto text-luxury-light mb-6" />
      <h1 className="font-display text-4xl text-luxury-cream mb-3">Your Cart is Empty</h1>
      <p className="font-body text-sm text-luxury-light mb-8">Discover our luxury collection</p>
      <Link href="/shop/products" className="btn-luxury inline-block">Shop Now</Link>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12">
      <h1 className="font-display text-4xl font-light mb-10" style={{ color: 'var(--text-primary)' }}>Shopping Cart <span className="text-luxury-light font-body text-lg">({items.length} items)</span></h1>
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          <AnimatePresence>
            {items.map(item => (
              <motion.div key={item.id} exit={{ opacity: 0, x: -20 }} className="card-luxury p-4 flex gap-4">
                <Link href={`/shop/products/${item.products?.slug}`}>
                  <img src={item.products?.images?.[0]} alt={item.products?.name} className="w-20 h-20 object-cover flex-shrink-0" />
                </Link>
                <div className="flex-1 min-w-0">
                  <Link href={`/shop/products/${item.products?.slug}`}>
                    <h3 className="font-body text-sm font-medium hover:text-gold transition-colors" style={{ color: 'var(--text-primary)' }}>{item.products?.name}</h3>
                  </Link>
                  {item.size && <p className="font-body text-xs text-luxury-light mt-0.5">Size: {item.size}</p>}
                  {item.color && <p className="font-body text-xs text-luxury-light">Color: {item.color}</p>}
                  <p className="font-body text-sm font-bold text-gold mt-2">KSh {item.products?.price?.toLocaleString()}</p>
                </div>
                <div className="flex flex-col items-end gap-3">
                  <button onClick={() => removeItem(item.id)} className="text-luxury-light hover:text-red-400 transition-colors"><Trash2 size={14} /></button>
                  <div className="flex items-center border border-gold/30">
                    <button onClick={() => updateQty(item.id, item.quantity - 1, item.products?.stock_quantity)} className="w-8 h-8 flex items-center justify-center text-luxury-light hover:text-gold"><Minus size={12} /></button>
                    <span className="w-8 text-center font-body text-xs" style={{ color: 'var(--text-primary)' }}>{item.quantity}</span>
                    <button onClick={() => updateQty(item.id, item.quantity + 1, item.products?.stock_quantity)} className="w-8 h-8 flex items-center justify-center text-luxury-light hover:text-gold"><Plus size={12} /></button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <div className="card-luxury p-6 h-fit">
          <h2 className="font-display text-2xl font-light mb-6" style={{ color: 'var(--text-primary)' }}>Order Summary</h2>
          <div className="space-y-3 mb-6">
            <div className="flex justify-between font-body text-sm" style={{ color: 'var(--text-secondary)' }}>
              <span>Subtotal</span><span>KSh {subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between font-body text-sm" style={{ color: 'var(--text-secondary)' }}>
              <span>Shipping</span><span className="text-green-400">Calculated at checkout</span>
            </div>
            <div className="h-px bg-gold/20" />
            <div className="flex justify-between font-body font-bold">
              <span style={{ color: 'var(--text-primary)' }}>Total</span>
              <span className="text-gold">KSh {subtotal.toLocaleString()}</span>
            </div>
          </div>
          <button onClick={handleCheckout} disabled={checkingOut} className="w-full btn-luxury flex items-center justify-center gap-2">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            Checkout via WhatsApp
          </button>
          <Link href="/shop/products" className="block text-center mt-3 font-body text-xs text-luxury-light hover:text-gold transition-colors">Continue Shopping</Link>
        </div>
      </div>
    </div>
  );
}
