'use client';
import { useState } from 'react';
import Link from 'next/link';
import { Heart, ShoppingBag, Star, Share2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { createClient } from '@/lib/supabase/client';
import toast from 'react-hot-toast';

const BADGE_LABELS: Record<string, string> = {
  trending: '🔥 Trending',
  best_seller: '⭐ Best Seller',
  premium: '💎 Premium',
  new: '✨ New',
  sale: '🏷️ Sale',
};

const BADGE_CLASSES: Record<string, string> = {
  trending: 'badge-trending',
  best_seller: 'badge-best-seller',
  premium: 'badge-premium',
  new: 'badge-new',
  sale: 'badge-sale',
};

export default function ProductCard({ product }: { product: any }) {
  const [wishlisted, setWishlisted] = useState(false);
  const [addingCart, setAddingCart] = useState(false);
  const supabase = createClient();

  const discount = product.compare_at_price && product.price < product.compare_at_price
    ? Math.round((1 - product.price / product.compare_at_price) * 100)
    : null;

  const isLowStock = product.stock_quantity > 0 && product.stock_quantity <= (product.low_stock_threshold || 5);
  const isOutOfStock = product.stock_quantity === 0;

  async function toggleWishlist(e: React.MouseEvent) {
    e.preventDefault();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { toast.error('Sign in to save items'); return; }
    if (wishlisted) {
      await supabase.from('wishlists').delete().match({ user_id: user.id, product_id: product.id });
      setWishlisted(false);
      toast.success('Removed from wishlist');
    } else {
      await supabase.from('wishlists').insert({ user_id: user.id, product_id: product.id });
      setWishlisted(true);
      toast.success('Added to wishlist');
    }
  }

  async function addToCart(e: React.MouseEvent) {
    e.preventDefault();
    if (isOutOfStock) return;
    setAddingCart(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { toast.error('Sign in to add to cart'); return; }
      const { error } = await supabase.from('cart_items').upsert(
        { user_id: user.id, product_id: product.id, quantity: 1 },
        { onConflict: 'user_id,product_id,size,color', ignoreDuplicates: false }
      );
      if (error) throw error;
      toast.success('Added to cart');
    } catch {
      toast.error('Failed to add to cart');
    } finally {
      setAddingCart(false);
    }
  }

  async function shareProduct(e: React.MouseEvent) {
    e.preventDefault();
    const url = `${window.location.origin}/shop/products/${product.slug}`;
    if (navigator.share) {
      await navigator.share({ title: product.name, url });
    } else {
      await navigator.clipboard.writeText(url);
      toast.success('Link copied!');
    }
  }

  return (
    <motion.div className="card-luxury group relative overflow-hidden" whileHover={{ y: -4 }} transition={{ duration: 0.3 }}>
      {/* Image */}
      <Link href={`/shop/products/${product.slug}`}>
        <div className="product-img-wrapper relative aspect-[4/5] overflow-hidden bg-luxury-dark">
          {product.images?.[0] ? (
            <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" loading="lazy" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-luxury-light">
              <ShoppingBag size={40} strokeWidth={1} />
            </div>
          )}

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1">
            {product.badge && (
              <span className={`${BADGE_CLASSES[product.badge]} text-[9px] font-bold font-body tracking-wider px-2 py-1 uppercase`}>
                {BADGE_LABELS[product.badge]}
              </span>
            )}
            {discount && (
              <span className="bg-red-600 text-white text-[9px] font-bold font-body tracking-wider px-2 py-1 uppercase">
                -{discount}%
              </span>
            )}
            {isLowStock && (
              <span className="bg-orange-500/90 text-white text-[9px] font-bold font-body px-2 py-1">
                Only {product.stock_quantity} left
              </span>
            )}
          </div>

          {/* Actions overlay */}
          <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button onClick={toggleWishlist} className={`p-2 bg-luxury-black/80 backdrop-blur-sm transition-colors ${wishlisted ? 'text-gold' : 'text-white hover:text-gold'}`}>
              <Heart size={14} fill={wishlisted ? 'currentColor' : 'none'} />
            </button>
            <button onClick={shareProduct} className="p-2 bg-luxury-black/80 backdrop-blur-sm text-white hover:text-gold transition-colors">
              <Share2 size={14} />
            </button>
          </div>

          {isOutOfStock && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <span className="font-body text-xs font-bold tracking-widest text-white uppercase bg-luxury-black/80 px-4 py-2">Out of Stock</span>
            </div>
          )}
        </div>
      </Link>

      {/* Info */}
      <div className="p-4">
        <Link href={`/shop/products/${product.slug}`}>
          <h3 className="font-body text-sm font-medium tracking-wide mb-1 hover:text-gold transition-colors line-clamp-2" style={{ color: 'var(--text-primary)' }}>
            {product.name}
          </h3>
        </Link>

        {/* Rating */}
        {product.rating && (
          <div className="flex items-center gap-1 mb-2">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={10} className={i < Math.floor(product.rating) ? 'text-gold fill-gold' : 'text-luxury-light'} />
            ))}
            <span className="font-body text-[10px] text-luxury-light ml-1">({product.review_count || 0})</span>
          </div>
        )}

        {/* Price */}
        <div className="flex items-center gap-2 mb-3">
          <span className="font-body text-sm font-bold text-gold">
            KSh {product.price?.toLocaleString()}
          </span>
          {product.compare_at_price && (
            <span className="font-body text-xs text-luxury-light line-through">
              KSh {product.compare_at_price?.toLocaleString()}
            </span>
          )}
        </div>

        {/* Add to cart */}
        <button
          onClick={addToCart}
          disabled={isOutOfStock || addingCart}
          className={`w-full py-2.5 text-xs font-body font-semibold tracking-widest uppercase transition-all duration-300 ${
            isOutOfStock
              ? 'bg-luxury-dark text-luxury-light cursor-not-allowed'
              : 'bg-gold-gradient text-black hover:shadow-gold hover:-translate-y-0.5'
          }`}
        >
          {addingCart ? 'Adding...' : isOutOfStock ? 'Out of Stock' : 'Add to Cart'}
        </button>
      </div>

      {/* Purchase notification simulation */}
      <motion.div
        className="absolute bottom-0 left-0 right-0 bg-luxury-charcoal/95 text-xs font-body text-luxury-light px-3 py-2 border-t border-gold/20"
        initial={{ y: 40 }}
        whileHover={{ y: 0 }}
        transition={{ duration: 0.3 }}
      >
        🛍️ Someone in Nairobi just viewed this
      </motion.div>
    </motion.div>
  );
}
