import ProductCard from './ProductCard';

export default function ProductsGrid({ products }: { products: any[] }) {
  if (!products.length) {
    return (
      <div className="text-center py-20">
        <p className="font-display text-3xl text-luxury-light mb-3">No products found</p>
        <p className="font-body text-sm text-luxury-light/60">Try a different search or category</p>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
      {products.map(product => <ProductCard key={product.id} product={product} />)}
    </div>
  );
}
