'use client';
import { useRouter, useSearchParams } from 'next/navigation';
import { useCallback } from 'react';

const SORT_OPTIONS = [
  { value: 'newest', label: 'Newest' },
  { value: 'popular', label: 'Most Popular' },
  { value: 'price_asc', label: 'Price: Low to High' },
  { value: 'price_desc', label: 'Price: High to Low' },
];

export default function ProductsFilter({ categories, currentParams }: { categories: any[]; currentParams: any }) {
  const router = useRouter();
  const params = useSearchParams();

  const updateParam = useCallback((key: string, value: string) => {
    const p = new URLSearchParams(params.toString());
    if (value) p.set(key, value); else p.delete(key);
    if (key !== 'sort') p.delete('sort');
    router.push(`/shop/products?${p.toString()}`);
  }, [params, router]);

  return (
    <div className="flex flex-wrap gap-3 mb-8 pb-6 border-b border-gold/10">
      <button
        onClick={() => router.push('/shop/products')}
        className={`font-body text-xs font-semibold tracking-widest uppercase px-4 py-2 border transition-colors ${!currentParams.category ? 'bg-gold text-black border-gold' : 'border-gold/30 text-luxury-light hover:border-gold hover:text-gold'}`}
      >
        All
      </button>
      {categories.map(cat => (
        <button
          key={cat.slug}
          onClick={() => updateParam('category', cat.slug)}
          className={`font-body text-xs font-semibold tracking-widest uppercase px-4 py-2 border transition-colors ${currentParams.category === cat.slug ? 'bg-gold text-black border-gold' : 'border-gold/30 text-luxury-light hover:border-gold hover:text-gold'}`}
        >
          {cat.name}
        </button>
      ))}

      <div className="ml-auto">
        <select
          value={currentParams.sort || 'newest'}
          onChange={e => updateParam('sort', e.target.value)}
          className="bg-transparent border border-gold/30 text-luxury-light font-body text-xs px-4 py-2 focus:outline-none focus:border-gold"
        >
          {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      </div>
    </div>
  );
}
