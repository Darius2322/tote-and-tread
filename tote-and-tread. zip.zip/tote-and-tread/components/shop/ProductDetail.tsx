'use client';
import { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Heart, ShoppingBag, Share2, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import ProductCard from './ProductCard';
import toast from 'react-hot-toast';
import { generateWhatsAppOrderMessage, getWhatsAppUrl } from '@/lib/whatsapp';

export default function ProductDetail({ product, related, reviews }: { product: any; related: any[]; reviews: any[] }) {
  const [activeImg, setActiveImg] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [qty, setQty] = useState(1);
  const [wishlisted, setWishlisted] = useState(false);
  const supabase = createClient();

  const images = product.images?.length ? product.images : ['https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800'];
  const avgRating = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;
  const isOutOfStock = product.stock_quantity === 0;
  const isLowStock = product.stock_quantity > 0 && product.stock_quantity <= (product.low_stock_threshold || 5);

  async function addToCart() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { toast.error('Sign in to add to cart'); return; }
    if (product.sizes?.length && !selectedSize) { toast.error('Please select a size'); return; }
    await supabase.from('cart_items').upsert({
      user_id: user.id, product_id: product.id, quantity: qty,
      size: selectedSize || null, color: selectedColor || null,
    }, { onConflict: 'user_id,product_id,size,color' });
    toast.success('Added to cart!');
  }

  async function buyNow() {
    const whatsappNum = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '+254700000000';
    const { data: { user } } = await supabase.auth.getUser();
    const { data: profile } = user ? await supabase.from('profiles').select('full_name, phone').eq('id', user!.id).single() : { data: null };
    const msg = generateWhatsAppOrderMessage({
      customerName: profile?.full_name || 'Customer',
      customerPhone: profile?.phone,
      items: [{ name: product.name, quantity: qty, price: product.price, size: selectedSize, color: selectedColor }],
      total: product.price * qty,
    });
    window.open(getWhatsAppUrl(whatsappNum, msg), '_blank');
  }

  async function toggleWishlist() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { toast.error('Sign in to save items'); return; }
    if (wishlisted) {
      await supabase.from('wishlists').delete().match({ user_id: user.id, product_id: product.id });
      setWishlisted(false); toast.success('Removed from wishlist');
    } else {
      await supabase.from('wishlists').insert({ user_id: user.id, product_id: product.id });
      setWishlisted(true); toast.success('Added to wishlist');
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 mb-8 font-body text-xs text-luxury-light">
        <Link href="/" className="hover:text-gold">Home</Link>
        <span>/</span>
        <Link href="/shop/products" className="hover:text-gold">Shop</Link>
        {product.categories && <><span>/</span><Link href={`/shop/products?category=${product.categories.slug}`} className="hover:text-gold">{product.categories.name}</Link></>}
        <span>/</span>
        <span className="text-gold truncate max-w-[200px]">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
        {/* Images */}
        <div>
          <div className="relative aspect-square overflow-hidden bg-luxury-dark mb-4">
            <motion.img
              key={activeImg}
              src={images[activeImg]}
              alt={product.name}
              className="w-full h-full object-cover"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            />
            {images.length > 1 && (
              <>
                <button onClick={() => setActiveImg(i => (i - 1 + images.length) % images.length)} className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/50 flex items-center justify-center text-white hover:bg-gold hover:text-black transition-colors">
                  <ChevronLeft size={18} />
                </button>
                <button onClick={() => setActiveImg(i => (i + 1) % images.length)} className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/50 flex items-center justify-center text-white hover:bg-gold hover:text-black transition-colors">
                  <ChevronRight size={18} />
                </button>
              </>
            )}
          </div>
          {images.length > 1 && (
            <div className="flex gap-2">
              {images.map((img: string, i: number) => (
                <button key={i} onClick={() => setActiveImg(i)} className={`w-16 h-16 overflow-hidden border-2 transition-colors ${activeImg === i ? 'border-gold' : 'border-transparent'}`}>
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div>
          {product.categories && (
            <Link href={`/shop/products?category=${product.categories.slug}`} className="font-body text-xs tracking-widest uppercase text-gold font-semibold mb-2 block">
              {product.categories.name}
            </Link>
          )}
          <h1 className="font-display text-4xl lg:text-5xl font-light mb-4" style={{ color: 'var(--text-primary)' }}>{product.name}</h1>

          {reviews.length > 0 && (
            <div className="flex items-center gap-2 mb-4">
              {[...Array(5)].map((_, i) => <Star key={i} size={14} className={i < Math.round(avgRating) ? 'text-gold fill-gold' : 'text-luxury-light'} />)}
              <span className="font-body text-xs text-luxury-light">({reviews.length} reviews)</span>
            </div>
          )}

          <div className="flex items-baseline gap-3 mb-6">
            <span className="font-display text-3xl text-gold">KSh {product.price?.toLocaleString()}</span>
            {product.compare_at_price && <span className="font-body text-sm text-luxury-light line-through">KSh {product.compare_at_price?.toLocaleString()}</span>}
          </div>

          {isLowStock && <p className="font-body text-xs text-orange-400 font-semibold mb-4 animate-pulse">⚡ Only {product.stock_quantity} items left!</p>}
          {isOutOfStock && <p className="font-body text-xs text-red-400 font-semibold mb-4">Out of Stock</p>}

          {product.description && <p className="font-body text-sm leading-relaxed mb-6" style={{ color: 'var(--text-secondary)' }}>{product.description}</p>}

          {/* Sizes */}
          {product.sizes?.length > 0 && (
            <div className="mb-6">
              <p className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light mb-3">Size</p>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((s: string) => (
                  <button key={s} onClick={() => setSelectedSize(s)} className={`px-4 py-2 border text-xs font-body font-semibold transition-colors ${selectedSize === s ? 'bg-gold text-black border-gold' : 'border-gold/30 text-luxury-light hover:border-gold'}`}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Colors */}
          {product.colors?.length > 0 && (
            <div className="mb-6">
              <p className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light mb-3">Color</p>
              <div className="flex flex-wrap gap-2">
                {product.colors.map((c: string) => (
                  <button key={c} onClick={() => setSelectedColor(c)} className={`px-4 py-2 border text-xs font-body font-semibold transition-colors ${selectedColor === c ? 'bg-gold text-black border-gold' : 'border-gold/30 text-luxury-light hover:border-gold'}`}>
                    {c}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity */}
          <div className="flex items-center gap-4 mb-8">
            <p className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light">Qty</p>
            <div className="flex items-center border border-gold/30">
              <button onClick={() => setQty(q => Math.max(1, q - 1))} className="w-10 h-10 flex items-center justify-center text-luxury-light hover:text-gold border-r border-gold/30">−</button>
              <span className="w-12 text-center font-body text-sm" style={{ color: 'var(--text-primary)' }}>{qty}</span>
              <button onClick={() => setQty(q => Math.min(product.stock_quantity, q + 1))} className="w-10 h-10 flex items-center justify-center text-luxury-light hover:text-gold border-l border-gold/30">+</button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 mb-4">
            <button onClick={addToCart} disabled={isOutOfStock} className={`flex-1 py-4 font-body text-sm font-semibold tracking-widest uppercase transition-all ${isOutOfStock ? 'bg-luxury-dark text-luxury-light cursor-not-allowed' : 'btn-luxury'}`}>
              <span className="flex items-center justify-center gap-2"><ShoppingBag size={16} /> Add to Cart</span>
            </button>
            <button onClick={toggleWishlist} className={`w-14 border border-gold/30 flex items-center justify-center hover:border-gold transition-colors ${wishlisted ? 'text-gold' : 'text-luxury-light'}`}>
              <Heart size={18} fill={wishlisted ? 'currentColor' : 'none'} />
            </button>
          </div>

          <button onClick={buyNow} className="w-full py-4 border border-green-500 text-green-400 hover:bg-green-500/10 font-body text-sm font-semibold tracking-widest uppercase transition-all flex items-center justify-center gap-2">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            Buy via WhatsApp
          </button>
        </div>
      </div>

      {/* Reviews */}
      {reviews.length > 0 && (
        <div className="mb-20">
          <h2 className="font-display text-3xl font-light mb-8" style={{ color: 'var(--text-primary)' }}>Customer Reviews</h2>
          <div className="space-y-4">
            {reviews.map(r => (
              <div key={r.id} className="card-luxury p-6">
                <div className="flex items-center gap-2 mb-2">
                  {[...Array(5)].map((_, i) => <Star key={i} size={12} className={i < r.rating ? 'text-gold fill-gold' : 'text-luxury-light'} />)}
                  <span className="font-body font-semibold text-sm ml-2" style={{ color: 'var(--text-primary)' }}>{r.profiles?.full_name || 'Customer'}</span>
                  {r.is_verified_purchase && <span className="text-xs text-green-400 font-body ml-1">✓ Verified</span>}
                </div>
                {r.title && <p className="font-body font-semibold text-sm mb-1" style={{ color: 'var(--text-primary)' }}>{r.title}</p>}
                {r.body && <p className="font-body text-sm" style={{ color: 'var(--text-secondary)' }}>{r.body}</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Related */}
      {related.length > 0 && (
        <div>
          <h2 className="font-display text-3xl font-light mb-8" style={{ color: 'var(--text-primary)' }}>You May Also Like</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {related.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      )}
    </div>
  );
}
