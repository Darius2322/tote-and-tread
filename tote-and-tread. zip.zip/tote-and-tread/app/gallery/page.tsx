import ShopLayout from '@/components/layout/ShopLayout';
import GalleryGrid from '@/components/shop/GalleryGrid';
import { createClient } from '@/lib/supabase/server';
import type { Metadata } from 'next';

export const metadata: Metadata = { title: 'Gallery' };

export default async function GalleryPage() {
  const supabase = await createClient();
  const { data: images } = await supabase.from('gallery').select('*').eq('is_active', true).order('display_order');

  const fallback = [
    { id: '1', image_url: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=600&q=80', title: 'Luxury Bag' },
    { id: '2', image_url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=600&q=80', title: 'Handbag' },
    { id: '3', image_url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80', title: 'Sneakers' },
    { id: '4', image_url: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&q=80', title: 'Travel Bag' },
    { id: '5', image_url: 'https://images.unsplash.com/photo-1614252369475-531eba835eb1?w=600&q=80', title: 'Formal Shoes' },
    { id: '6', image_url: 'https://images.unsplash.com/photo-1491553895911-0055eca6402d?w=600&q=80', title: 'Footwear' },
  ];

  return (
    <ShopLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-16">
          <span className="font-body text-xs tracking-[0.4em] uppercase text-gold font-semibold">Lifestyle</span>
          <h1 className="font-display text-6xl font-light mt-2" style={{ color: 'var(--text-primary)' }}>
            The <span className="text-gold-gradient italic">Gallery</span>
          </h1>
          <div className="divider-gold mt-6" />
        </div>
        <GalleryGrid images={images?.length ? images : fallback} />
      </div>
    </ShopLayout>
  );
}
