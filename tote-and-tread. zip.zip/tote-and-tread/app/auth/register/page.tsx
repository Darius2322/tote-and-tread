'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Eye, EyeOff, CheckCircle } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { createClient } from '@/lib/supabase/client';
import { registerSchema, type RegisterInput } from '@/lib/validation';
import toast from 'react-hot-toast';

export default function RegisterPage() {
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const router = useRouter();

  const { register, handleSubmit, watch, formState: { errors } } = useForm<RegisterInput>({
    resolver: zodResolver(registerSchema),
  });
  const password = watch('password', '');

  const passwordChecks = [
    { label: 'At least 8 characters', pass: password.length >= 8 },
    { label: 'Uppercase letter', pass: /[A-Z]/.test(password) },
    { label: 'Lowercase letter', pass: /[a-z]/.test(password) },
    { label: 'Number', pass: /\d/.test(password) },
  ];

  async function onSubmit(data: RegisterInput) {
    setLoading(true);
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: { data: { full_name: data.full_name } },
      });
      if (error) {
        if (error.message.includes('already registered')) {
          toast.error('This email is already registered');
        } else {
          toast.error('Registration failed. Please try again.');
        }
        return;
      }
      setSuccess(true);
    } finally {
      setLoading(false);
    }
  }

  if (success) {
    return (
      <div className="min-h-screen bg-luxury-black flex items-center justify-center px-6">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center max-w-sm">
          <div className="w-20 h-20 rounded-full bg-gold-gradient flex items-center justify-center mx-auto mb-6">
            <CheckCircle size={36} className="text-black" />
          </div>
          <h2 className="font-display text-4xl text-luxury-cream mb-3">Check Your Email</h2>
          <p className="font-body text-sm text-luxury-light mb-6">We've sent a confirmation link to your email. Click it to activate your account.</p>
          <Link href="/auth/login" className="btn-luxury inline-block">Go to Login</Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-luxury-black flex items-center justify-center px-6 py-20">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm">
        <div className="text-center mb-10">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-full bg-gold-gradient flex items-center justify-center">
              <span className="font-display font-bold text-black">T</span>
            </div>
            <span className="font-display text-xl text-gold-gradient">Tote & Tread</span>
          </Link>
          <h1 className="font-display text-4xl font-light text-luxury-cream mb-2">Create Account</h1>
          <p className="font-body text-xs text-luxury-light">Join our luxury community</p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-7" noValidate>
          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Full Name</label>
            <input {...register('full_name')} type="text" autoComplete="name" className="input-luxury" placeholder="Your full name" />
            {errors.full_name && <p className="mt-1 text-xs text-red-400">{errors.full_name.message}</p>}
          </div>

          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Email</label>
            <input {...register('email')} type="email" autoComplete="email" className="input-luxury" placeholder="your@email.com" />
            {errors.email && <p className="mt-1 text-xs text-red-400">{errors.email.message}</p>}
          </div>

          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Password</label>
            <div className="relative">
              <input {...register('password')} type={showPwd ? 'text' : 'password'} autoComplete="new-password" className="input-luxury pr-10" placeholder="Create a strong password" />
              <button type="button" onClick={() => setShowPwd(!showPwd)} className="absolute right-0 top-3 text-luxury-light hover:text-gold">
                {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            {password && (
              <div className="mt-3 space-y-1">
                {passwordChecks.map(c => (
                  <div key={c.label} className={`flex items-center gap-2 text-xs font-body transition-colors ${c.pass ? 'text-green-400' : 'text-luxury-light'}`}>
                    <CheckCircle size={12} className={c.pass ? 'text-green-400' : 'text-luxury-light/30'} />
                    {c.label}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Confirm Password</label>
            <input {...register('confirm_password')} type="password" autoComplete="new-password" className="input-luxury" placeholder="Confirm your password" />
            {errors.confirm_password && <p className="mt-1 text-xs text-red-400">{errors.confirm_password.message}</p>}
          </div>

          <button type="submit" disabled={loading} className="btn-luxury w-full text-center">
            {loading ? 'Creating Account...' : 'Create Account'}
          </button>
        </form>

        <p className="text-center mt-6 font-body text-xs text-luxury-light">
          Already have an account?{' '}
          <Link href="/auth/login" className="text-gold hover:text-gold-light font-semibold">Sign in</Link>
        </p>
      </motion.div>
    </div>
  );
}
