'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { motion } from 'framer-motion';
import { Eye, EyeOff } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { createClient } from '@/lib/supabase/client';
import { loginSchema, type LoginInput } from '@/lib/validation';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const params = useSearchParams();
  const redirect = params.get('redirect') || '/user/dashboard';

  const { register, handleSubmit, formState: { errors } } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
  });

  async function onSubmit(data: LoginInput) {
    setLoading(true);
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signInWithPassword({ email: data.email, password: data.password });
      if (error) {
        // Generic error to prevent user enumeration
        toast.error('Invalid email or password');
        return;
      }
      toast.success('Welcome back!');
      router.push(redirect);
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-luxury-black flex">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        <img src="https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=900&q=80" alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/60" />
        <div className="relative z-10 flex flex-col justify-end p-12">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-gold-gradient flex items-center justify-center">
              <span className="font-display font-bold text-xl text-black">T</span>
            </div>
            <span className="font-display text-2xl font-bold text-gold-gradient">Tote & Tread</span>
          </div>
          <h2 className="font-display text-4xl font-light text-white mb-3">Step Into Style.</h2>
          <p className="font-body text-sm text-luxury-light">Carry Confidence.</p>
        </div>
      </div>

      {/* Right panel */}
      <div className="w-full lg:w-1/2 flex items-center justify-center px-6 py-20">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm">
          <div className="text-center mb-10">
            <h1 className="font-display text-4xl font-light text-luxury-cream mb-2">Welcome Back</h1>
            <p className="font-body text-xs text-luxury-light tracking-wide">Sign in to your account</p>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-8" noValidate>
            <div>
              <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Email</label>
              <input {...register('email')} type="email" autoComplete="email" className="input-luxury" placeholder="your@email.com" />
              {errors.email && <p className="mt-1 text-xs text-red-400">{errors.email.message}</p>}
            </div>

            <div>
              <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Password</label>
              <div className="relative">
                <input {...register('password')} type={showPwd ? 'text' : 'password'} autoComplete="current-password" className="input-luxury pr-10" placeholder="••••••••" />
                <button type="button" onClick={() => setShowPwd(!showPwd)} className="absolute right-0 top-3 text-luxury-light hover:text-gold">
                  {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {errors.password && <p className="mt-1 text-xs text-red-400">{errors.password.message}</p>}
            </div>

            <div className="flex justify-end">
              <Link href="/auth/reset-password" className="font-body text-xs text-gold hover:text-gold-light transition-colors">
                Forgot password?
              </Link>
            </div>

            <button type="submit" disabled={loading} className="btn-luxury w-full text-center">
              {loading ? 'Signing In...' : 'Sign In'}
            </button>
          </form>

          <p className="text-center mt-8 font-body text-xs text-luxury-light">
            Don't have an account?{' '}
            <Link href="/auth/register" className="text-gold hover:text-gold-light transition-colors font-semibold">Create one</Link>
          </p>

          <div className="text-center mt-4">
            <Link href="/" className="font-body text-xs text-luxury-light/50 hover:text-luxury-light transition-colors">← Back to Store</Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
