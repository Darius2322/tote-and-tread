'use client';
import { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { createClient } from '@/lib/supabase/client';
import { resetPasswordSchema } from '@/lib/validation';
import toast from 'react-hot-toast';

export default function ResetPasswordPage() {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(resetPasswordSchema) });

  async function onSubmit({ email }: { email: string }) {
    setLoading(true);
    try {
      const supabase = createClient();
      await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/update-password`,
      });
      // Always show success to prevent email enumeration
      setSent(true);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-luxury-black flex items-center justify-center px-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm">
        <div className="text-center mb-10">
          <Link href="/" className="inline-flex items-center gap-2 mb-8">
            <div className="w-8 h-8 rounded-full bg-gold-gradient flex items-center justify-center">
              <span className="font-display font-bold text-black">T</span>
            </div>
            <span className="font-display text-xl text-gold-gradient">Tote & Tread</span>
          </Link>
          <h1 className="font-display text-4xl font-light text-luxury-cream mb-2">Reset Password</h1>
          <p className="font-body text-xs text-luxury-light">Enter your email to receive a reset link</p>
        </div>

        {sent ? (
          <div className="text-center bg-luxury-charcoal border border-gold/20 p-8">
            <p className="font-body text-sm text-luxury-light mb-4">
              If an account exists for that email, you'll receive a password reset link shortly.
            </p>
            <Link href="/auth/login" className="text-gold font-body text-sm hover:text-gold-light">← Back to Login</Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit as any)} className="space-y-8" noValidate>
            <div>
              <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Email</label>
              <input {...register('email')} type="email" autoComplete="email" className="input-luxury" placeholder="your@email.com" />
              {errors.email && <p className="mt-1 text-xs text-red-400">{errors.email.message as string}</p>}
            </div>
            <button type="submit" disabled={loading} className="btn-luxury w-full">{loading ? 'Sending...' : 'Send Reset Link'}</button>
            <div className="text-center">
              <Link href="/auth/login" className="font-body text-xs text-luxury-light hover:text-gold transition-colors">← Back to Login</Link>
            </div>
          </form>
        )}
      </motion.div>
    </div>
  );
}
