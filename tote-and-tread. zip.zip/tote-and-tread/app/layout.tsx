import type { Metadata, Viewport } from 'next';
import { Toaster } from 'react-hot-toast';
import './globals.css';

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://toteandtread.com';

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: 'Tote & Tread | Luxury Bags & Footwear',
    template: '%s | Tote & Tread',
  },
  description: 'Step Into Style. Carry Confidence. Discover premium luxury bags and footwear at Tote & Tread — where elegance meets every step.',
  keywords: ['luxury bags', 'designer footwear', 'handbags', 'sneakers', 'formal shoes', 'travel bags', 'premium fashion'],
  authors: [{ name: 'Tote & Tread' }],
  creator: 'Tote & Tread',
  publisher: 'Tote & Tread',
  robots: { index: true, follow: true, googleBot: { index: true, follow: true } },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: siteUrl,
    siteName: 'Tote & Tread',
    title: 'Tote & Tread | Luxury Bags & Footwear',
    description: 'Step Into Style. Carry Confidence. Premium luxury bags and footwear.',
    images: [{ url: '/og-image.jpg', width: 1200, height: 630, alt: 'Tote & Tread' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Tote & Tread | Luxury Bags & Footwear',
    description: 'Step Into Style. Carry Confidence.',
    images: ['/og-image.jpg'],
  },
  manifest: '/manifest.json',
  icons: {
    icon: [
      { url: '/icons/icon-32.png', sizes: '32x32', type: 'image/png' },
      { url: '/icons/icon-192.png', sizes: '192x192', type: 'image/png' },
    ],
    apple: [{ url: '/icons/icon-180.png', sizes: '180x180', type: 'image/png' }],
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: dark)', color: '#0A0A0A' },
    { media: '(prefers-color-scheme: light)', color: '#F5F5F0' },
  ],
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                try {
                  var theme = localStorage.getItem('theme') || 'dark';
                  document.documentElement.setAttribute('data-theme', theme);
                } catch(e) {}
              })();
            `,
          }}
        />
      </head>
      <body>
        {children}
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: '#1A1A1A',
              color: '#F5F5F0',
              border: '1px solid rgba(201,168,76,0.3)',
              fontFamily: 'Montserrat, sans-serif',
              fontSize: '13px',
            },
            success: { iconTheme: { primary: '#C9A84C', secondary: '#0A0A0A' } },
            error: { iconTheme: { primary: '#E53935', secondary: '#fff' } },
          }}
        />
      </body>
    </html>
  );
}
