import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import AdminNav from '@/components/admin/AdminNav';
import AdminPromotionsClient from '@/components/admin/AdminPromotionsClient';

export const metadata = { title: 'Promotions - Admin' };

export default async function AdminPromotionsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (profile?.role !== 'admin') redirect('/');
  const { data: promos } = await supabase.from('promotions').select('*').order('created_at', { ascending: false });

  return (
    <div className="flex min-h-screen bg-luxury-black">
      <AdminNav />
      <main className="flex-1 p-8 ml-64">
        <h1 className="font-display text-4xl font-light text-luxury-cream mb-8">Promotions & Notices</h1>
        <AdminPromotionsClient initialPromos={promos || []} />
      </main>
    </div>
  );
}
