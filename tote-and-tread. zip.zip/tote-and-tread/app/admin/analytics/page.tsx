import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import AdminNav from '@/components/admin/AdminNav';

export const metadata = { title: 'Analytics - Admin' };

export default async function AdminAnalyticsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (profile?.role !== 'admin') redirect('/');

  const [
    { count: totalUsers },
    { count: totalOrders },
    { count: totalProducts },
    { data: topProducts },
    { data: recentEvents },
  ] = await Promise.all([
    supabase.from('profiles').select('*', { count: 'exact', head: true }),
    supabase.from('orders').select('*', { count: 'exact', head: true }),
    supabase.from('products').select('*', { count: 'exact', head: true }).eq('is_active', true),
    supabase.from('products').select('name, view_count, purchase_count').order('purchase_count', { ascending: false }).limit(10),
    supabase.from('analytics_events').select('event_type, created_at').order('created_at', { ascending: false }).limit(20),
  ]);

  const { data: revenue } = await supabase.from('orders').select('total').eq('status', 'delivered');
  const totalRevenue = revenue?.reduce((s, o) => s + (o.total || 0), 0) || 0;

  return (
    <div className="flex min-h-screen bg-luxury-black">
      <AdminNav />
      <main className="flex-1 p-8 ml-64">
        <h1 className="font-display text-4xl font-light text-luxury-cream mb-8">Analytics</h1>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Users', value: totalUsers || 0, color: 'text-blue-400' },
            { label: 'Total Orders', value: totalOrders || 0, color: 'text-purple-400' },
            { label: 'Active Products', value: totalProducts || 0, color: 'text-gold' },
            { label: 'Revenue (KSh)', value: totalRevenue.toLocaleString(), color: 'text-green-400' },
          ].map(s => (
            <div key={s.label} className="card-luxury p-6">
              <p className={`font-display text-3xl font-light ${s.color}`}>{s.value}</p>
              <p className="font-body text-xs text-luxury-light tracking-wide mt-1">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <div className="card-luxury p-6">
            <h2 className="font-display text-xl text-luxury-cream mb-6">Top Products by Sales</h2>
            <div className="space-y-3">
              {topProducts?.map((p, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="font-display text-xl text-gold/40 w-8">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-body text-xs text-luxury-cream truncate">{p.name}</p>
                    <div className="flex gap-2 mt-1">
                      <div className="h-1 bg-gold/20 flex-1 rounded"><div className="h-1 bg-gold rounded" style={{ width: `${Math.min(100, (p.purchase_count / (topProducts[0]?.purchase_count || 1)) * 100)}%` }} /></div>
                    </div>
                  </div>
                  <span className="font-body text-xs text-gold font-bold">{p.purchase_count} sold</span>
                </div>
              ))}
              {!topProducts?.length && <p className="font-body text-xs text-luxury-light text-center py-6">No data yet</p>}
            </div>
          </div>

          <div className="card-luxury p-6">
            <h2 className="font-display text-xl text-luxury-cream mb-6">Recent Events</h2>
            <div className="space-y-2">
              {recentEvents?.map((e, i) => (
                <div key={i} className="flex items-center justify-between py-2 border-b border-gold/5">
                  <span className="font-body text-xs text-luxury-light">{e.event_type.replace(/_/g, ' ')}</span>
                  <span className="font-body text-[10px] text-luxury-light/50">{new Date(e.created_at).toLocaleTimeString()}</span>
                </div>
              ))}
              {!recentEvents?.length && <p className="font-body text-xs text-luxury-light text-center py-6">No events yet</p>}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
