import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import AdminNav from '@/components/admin/AdminNav';
import AdminOrdersClient from '@/components/admin/AdminOrdersClient';

export const metadata = { title: 'Orders - Admin' };

export default async function AdminOrdersPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (profile?.role !== 'admin') redirect('/');

  const { data: orders } = await supabase
    .from('orders')
    .select('*, profiles(full_name, email), order_items(product_name, quantity, price)')
    .order('created_at', { ascending: false });

  return (
    <div className="flex min-h-screen bg-luxury-black">
      <AdminNav />
      <main className="flex-1 p-8 ml-64">
        <h1 className="font-display text-4xl font-light text-luxury-cream mb-8">Orders</h1>
        <AdminOrdersClient initialOrders={orders || []} />
      </main>
    </div>
  );
}
