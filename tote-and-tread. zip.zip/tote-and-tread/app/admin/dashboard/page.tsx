import { redirect } from 'next/navigation';
import Link from 'next/link';
import type { Metadata } from 'next';
import { createClient } from '@/lib/supabase/server';
import AdminNav from '@/components/admin/AdminNav';
import { Users, Package, ShoppingCart, TrendingUp, DollarSign, Eye } from 'lucide-react';

export const metadata: Metadata = { title: 'Admin Dashboard' };

export default async function AdminDashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login?redirect=/admin/dashboard');
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (profile?.role !== 'admin') redirect('/?error=unauthorized');

  const [
    { count: userCount },
    { count: productCount },
    { count: orderCount },
    { data: recentOrders },
    { data: topProducts },
  ] = await Promise.all([
    supabase.from('profiles').select('*', { count: 'exact', head: true }),
    supabase.from('products').select('*', { count: 'exact', head: true }).eq('is_active', true),
    supabase.from('orders').select('*', { count: 'exact', head: true }),
    supabase.from('orders').select('*, profiles(full_name, email)').order('created_at', { ascending: false }).limit(5),
    supabase.from('products').select('name, purchase_count, view_count').order('purchase_count', { ascending: false }).limit(5),
  ]);

  const { data: revenue } = await supabase.from('orders').select('total').eq('status', 'delivered');
  const totalRevenue = revenue?.reduce((s, o) => s + (o.total || 0), 0) || 0;

  const stats = [
    { icon: Users, label: 'Total Users', value: userCount || 0, color: 'text-blue-400', bg: 'bg-blue-400/10' },
    { icon: Package, label: 'Products', value: productCount || 0, color: 'text-gold', bg: 'bg-gold/10' },
    { icon: ShoppingCart, label: 'Total Orders', value: orderCount || 0, color: 'text-purple-400', bg: 'bg-purple-400/10' },
    { icon: DollarSign, label: 'Revenue (KSh)', value: totalRevenue.toLocaleString(), color: 'text-green-400', bg: 'bg-green-400/10' },
  ];

  return (
    <div className="flex min-h-screen bg-luxury-black">
      <AdminNav />
      <main className="flex-1 p-8 ml-64">
        <div className="mb-8">
          <h1 className="font-display text-4xl font-light text-luxury-cream">Dashboard</h1>
          <p className="font-body text-xs text-luxury-light mt-1 tracking-wide">Welcome back, Admin</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map(({ icon: Icon, label, value, color, bg }) => (
            <div key={label} className="card-luxury p-6">
              <div className={`inline-flex p-3 rounded-full ${bg} mb-4`}>
                <Icon size={20} className={color} />
              </div>
              <p className="font-display text-3xl font-light text-luxury-cream">{value}</p>
              <p className="font-body text-xs text-luxury-light tracking-wide mt-1">{label}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent orders */}
          <div className="card-luxury p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-xl text-luxury-cream">Recent Orders</h2>
              <Link href="/admin/orders" className="font-body text-xs text-gold hover:text-gold-light">View All →</Link>
            </div>
            <div className="space-y-3">
              {recentOrders?.map(order => (
                <div key={order.id} className="flex items-center justify-between py-3 border-b border-gold/10">
                  <div>
                    <p className="font-body text-xs font-semibold text-luxury-cream">{order.order_number}</p>
                    <p className="font-body text-xs text-luxury-light">{(order.profiles as any)?.full_name || 'Guest'}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-body text-xs font-bold text-gold">KSh {order.total?.toLocaleString()}</p>
                    <span className={`font-body text-[10px] px-2 py-0.5 font-semibold uppercase tracking-wide ${
                      order.status === 'delivered' ? 'text-green-400 bg-green-400/10' :
                      order.status === 'pending' ? 'text-yellow-400 bg-yellow-400/10' :
                      'text-blue-400 bg-blue-400/10'
                    }`}>{order.status}</span>
                  </div>
                </div>
              ))}
              {!recentOrders?.length && <p className="font-body text-xs text-luxury-light text-center py-6">No orders yet</p>}
            </div>
          </div>

          {/* Top Products */}
          <div className="card-luxury p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-xl text-luxury-cream">Top Products</h2>
              <Link href="/admin/products" className="font-body text-xs text-gold hover:text-gold-light">Manage →</Link>
            </div>
            <div className="space-y-3">
              {topProducts?.map((p, i) => (
                <div key={i} className="flex items-center gap-3 py-2 border-b border-gold/10">
                  <span className="font-display text-2xl text-gold/40 w-8">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-body text-xs font-semibold text-luxury-cream truncate">{p.name}</p>
                    <div className="flex gap-4 mt-0.5">
                      <span className="font-body text-[10px] text-luxury-light flex items-center gap-1"><ShoppingCart size={10} />{p.purchase_count} sold</span>
                      <span className="font-body text-[10px] text-luxury-light flex items-center gap-1"><Eye size={10} />{p.view_count} views</span>
                    </div>
                  </div>
                </div>
              ))}
              {!topProducts?.length && <p className="font-body text-xs text-luxury-light text-center py-6">No products yet</p>}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
