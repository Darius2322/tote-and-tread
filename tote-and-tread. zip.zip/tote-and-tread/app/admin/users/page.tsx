import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import AdminNav from '@/components/admin/AdminNav';
import { format } from 'date-fns';

export const metadata = { title: 'Users - Admin' };

export default async function AdminUsersPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (profile?.role !== 'admin') redirect('/');

  const { data: users } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });

  return (
    <div className="flex min-h-screen bg-luxury-black">
      <AdminNav />
      <main className="flex-1 p-8 ml-64">
        <h1 className="font-display text-4xl font-light text-luxury-cream mb-8">Users <span className="font-body text-xl text-luxury-light">({users?.length || 0})</span></h1>
        <div className="card-luxury overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-gold/10">
                <tr>{['Name', 'Email', 'Role', 'Joined', 'Theme'].map(h => <th key={h} className="text-left px-4 py-3 font-body text-xs font-bold tracking-widest uppercase text-luxury-light">{h}</th>)}</tr>
              </thead>
              <tbody>
                {users?.map(u => (
                  <tr key={u.id} className="border-b border-gold/5 hover:bg-gold/5 transition-colors">
                    <td className="px-4 py-3 font-body text-xs text-luxury-cream">{u.full_name || '—'}</td>
                    <td className="px-4 py-3 font-body text-xs text-luxury-light">{u.email}</td>
                    <td className="px-4 py-3"><span className={`font-body text-[10px] font-bold tracking-widest uppercase px-2 py-1 ${u.role === 'admin' ? 'bg-gold/20 text-gold' : 'bg-blue-400/10 text-blue-400'}`}>{u.role}</span></td>
                    <td className="px-4 py-3 font-body text-xs text-luxury-light">{format(new Date(u.created_at), 'MMM d, yyyy')}</td>
                    <td className="px-4 py-3 font-body text-xs text-luxury-light">{u.theme_preference}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
