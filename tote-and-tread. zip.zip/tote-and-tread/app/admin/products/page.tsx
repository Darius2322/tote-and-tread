import { redirect } from 'next/navigation';
import Link from 'next/link';
import type { Metadata } from 'next';
import { createClient } from '@/lib/supabase/server';
import AdminNav from '@/components/admin/AdminNav';
import { Plus, Edit, Trash2, Eye, EyeOff } from 'lucide-react';

export const metadata: Metadata = { title: 'Manage Products - Admin' };

export default async function AdminProductsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (profile?.role !== 'admin') redirect('/');

  const { data: products } = await supabase
    .from('products')
    .select('*, categories(name)')
    .order('created_at', { ascending: false });

  return (
    <div className="flex min-h-screen bg-luxury-black">
      <AdminNav />
      <main className="flex-1 p-8 ml-64">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display text-4xl font-light text-luxury-cream">Products</h1>
            <p className="font-body text-xs text-luxury-light mt-1">{products?.length || 0} total products</p>
          </div>
          <Link href="/admin/products/new" className="btn-luxury flex items-center gap-2 text-xs">
            <Plus size={14} /> Add Product
          </Link>
        </div>

        <div className="card-luxury overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-gold/10">
                <tr>
                  {['Product', 'Category', 'Price', 'Stock', 'Status', 'Actions'].map(h => (
                    <th key={h} className="text-left px-4 py-3 font-body text-xs font-bold tracking-widest uppercase text-luxury-light">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {products?.map(p => (
                  <tr key={p.id} className="border-b border-gold/5 hover:bg-gold/5 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        {p.images?.[0] && <img src={p.images[0]} alt="" className="w-10 h-10 object-cover flex-shrink-0" />}
                        <div>
                          <p className="font-body text-xs font-semibold text-luxury-cream">{p.name}</p>
                          {p.badge && <span className="font-body text-[10px] text-gold">{p.badge}</span>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 font-body text-xs text-luxury-light">{(p.categories as any)?.name || '—'}</td>
                    <td className="px-4 py-3 font-body text-xs font-bold text-gold">KSh {p.price?.toLocaleString()}</td>
                    <td className="px-4 py-3">
                      <span className={`font-body text-xs font-semibold ${p.stock_quantity === 0 ? 'text-red-400' : p.stock_quantity <= 5 ? 'text-orange-400' : 'text-green-400'}`}>
                        {p.stock_quantity}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`font-body text-[10px] font-bold tracking-widest uppercase px-2 py-1 ${p.is_active ? 'bg-green-400/10 text-green-400' : 'bg-red-400/10 text-red-400'}`}>
                        {p.is_active ? 'Active' : 'Hidden'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Link href={`/admin/products/${p.id}/edit`} className="p-1.5 text-luxury-light hover:text-gold transition-colors"><Edit size={14} /></Link>
                        <Link href={`/shop/products/${p.slug}`} target="_blank" className="p-1.5 text-luxury-light hover:text-blue-400 transition-colors"><Eye size={14} /></Link>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!products?.length && (
              <div className="text-center py-16">
                <p className="font-body text-sm text-luxury-light">No products yet.</p>
                <Link href="/admin/products/new" className="mt-4 inline-block btn-luxury text-xs">Add Your First Product</Link>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
