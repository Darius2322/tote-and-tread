import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import AdminNav from '@/components/admin/AdminNav';
import ProductForm from '@/components/admin/ProductForm';

export const metadata = { title: 'Add Product - Admin' };

export default async function NewProductPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');
  const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (profile?.role !== 'admin') redirect('/');
  const { data: categories } = await supabase.from('categories').select('id, name').eq('is_active', true);

  return (
    <div className="flex min-h-screen bg-luxury-black">
      <AdminNav />
      <main className="flex-1 p-8 ml-64">
        <h1 className="font-display text-4xl font-light text-luxury-cream mb-8">Add New Product</h1>
        <ProductForm categories={categories || []} />
      </main>
    </div>
  );
}
