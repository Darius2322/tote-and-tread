import ShopLayout from '@/components/layout/ShopLayout';
import CartContent from '@/components/shop/CartContent';
export const metadata = { title: 'Shopping Cart' };
export default function CartPage() {
  return <ShopLayout><CartContent /></ShopLayout>;
}
