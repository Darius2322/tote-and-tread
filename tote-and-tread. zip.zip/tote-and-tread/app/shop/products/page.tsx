import { Suspense } from 'react';
import type { Metadata } from 'next';
import ShopLayout from '@/components/layout/ShopLayout';
import ProductsGrid from '@/components/shop/ProductsGrid';
import ProductsFilter from '@/components/shop/ProductsFilter';
import { createClient } from '@/lib/supabase/server';

export const metadata: Metadata = { title: 'Shop All Products' };
export const revalidate = 30;

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: { category?: string; sort?: string; q?: string; badge?: string };
}) {
  const supabase = await createClient();

  let query = supabase
    .from('products')
    .select('*, categories(name, slug)')
    .eq('is_active', true);

  if (searchParams.category) {
    const { data: cat } = await supabase.from('categories').select('id').eq('slug', searchParams.category).single();
    if (cat) query = query.eq('category_id', cat.id);
  }
  if (searchParams.badge) query = query.eq('badge', searchParams.badge);
  if (searchParams.q) query = query.ilike('name', `%${searchParams.q}%`);

  const sort = searchParams.sort || 'newest';
  if (sort === 'newest') query = query.order('created_at', { ascending: false });
  else if (sort === 'price_asc') query = query.order('price', { ascending: true });
  else if (sort === 'price_desc') query = query.order('price', { ascending: false });
  else if (sort === 'popular') query = query.order('view_count', { ascending: false });

  const { data: products } = await query.limit(48);
  const { data: categories } = await supabase.from('categories').select('*').eq('is_active', true);

  return (
    <ShopLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-10">
          <span className="font-body text-xs tracking-[0.4em] uppercase text-gold font-semibold">
            {searchParams.category || 'All Collections'}
          </span>
          <h1 className="font-display text-5xl font-light mt-1" style={{ color: 'var(--text-primary)' }}>
            {searchParams.q ? `Search: "${searchParams.q}"` : 'Our Products'}
          </h1>
          <p className="font-body text-sm mt-2" style={{ color: 'var(--text-secondary)' }}>
            {products?.length || 0} items found
          </p>
        </div>

        <ProductsFilter categories={categories || []} currentParams={searchParams} />
        <Suspense fallback={<div className="grid grid-cols-2 md:grid-cols-4 gap-4">{[...Array(8)].map((_, i) => <div key={i} className="skeleton aspect-[3/4]" />)}</div>}>
          <ProductsGrid products={products || []} />
        </Suspense>
      </div>
    </ShopLayout>
  );
}
