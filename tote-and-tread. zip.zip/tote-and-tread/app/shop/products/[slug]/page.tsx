import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import ShopLayout from '@/components/layout/ShopLayout';
import ProductDetail from '@/components/shop/ProductDetail';
import { createClient } from '@/lib/supabase/server';

export const revalidate = 60;

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const supabase = await createClient();
  const { data } = await supabase.from('products').select('name, meta_title, meta_description, images').eq('slug', params.slug).single();
  if (!data) return { title: 'Product Not Found' };
  return {
    title: data.meta_title || data.name,
    description: data.meta_description,
    openGraph: { images: data.images?.[0] ? [data.images[0]] : [] },
  };
}

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const supabase = await createClient();

  const { data: product } = await supabase
    .from('products')
    .select('*, categories(name, slug)')
    .eq('slug', params.slug)
    .eq('is_active', true)
    .single();

  if (!product) notFound();

  // Increment view count
  await supabase.rpc('increment_view_count', { product_id: product.id }).catch(() => {});

  // Get related products
  const { data: related } = await supabase
    .from('products')
    .select('*')
    .eq('category_id', product.category_id)
    .eq('is_active', true)
    .neq('id', product.id)
    .limit(4);

  // Get reviews
  const { data: reviews } = await supabase
    .from('reviews')
    .select('*, profiles(full_name, avatar_url)')
    .eq('product_id', product.id)
    .eq('is_approved', true)
    .order('created_at', { ascending: false })
    .limit(10);

  return (
    <ShopLayout>
      <ProductDetail product={product} related={related || []} reviews={reviews || []} />
    </ShopLayout>
  );
}
