import ShopLayout from '@/components/layout/ShopLayout';
import HeroSection from '@/components/home/HeroSection';
import CategorySection from '@/components/home/CategorySection';
import FeaturedProducts from '@/components/home/FeaturedProducts';
import TrendingSection from '@/components/home/TrendingSection';
import PromotionBanner from '@/components/home/PromotionBanner';
import ExitIntent from '@/components/home/ExitIntent';
import { createClient } from '@/lib/supabase/server';

export const revalidate = 60;

export default async function HomePage() {
  const supabase = await createClient();

  const [
    { data: featured },
    { data: trending },
    { data: categories },
    { data: promotions },
  ] = await Promise.all([
    supabase.from('products').select('*').eq('is_active', true).eq('is_featured', true).limit(8),
    supabase.from('products').select('*').eq('is_active', true).order('view_count', { ascending: false }).limit(10),
    supabase.from('categories').select('*').eq('is_active', true).order('display_order'),
    supabase.from('promotions').select('*').eq('is_active', true)
      .or('ends_at.is.null,ends_at.gt.' + new Date().toISOString())
      .order('created_at', { ascending: false }).limit(3),
  ]);

  const bannerPromo = promotions?.find(p => p.display_type === 'banner');
  const popupPromo = promotions?.find(p => p.display_type === 'popup');

  return (
    <ShopLayout>
      <HeroSection />
      {bannerPromo && <PromotionBanner promo={bannerPromo} />}
      <CategorySection categories={categories || []} />
      <FeaturedProducts products={featured || []} />
      <TrendingSection products={trending || []} />
      <ExitIntent promo={popupPromo} />
    </ShopLayout>
  );
}
