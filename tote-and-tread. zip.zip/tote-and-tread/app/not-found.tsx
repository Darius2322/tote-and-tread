import Link from 'next/link';
export default function NotFound() {
  return (
    <div className="min-h-screen bg-luxury-black flex items-center justify-center px-6">
      <div className="text-center">
        <p className="font-display text-[12rem] font-light leading-none text-gold/10">404</p>
        <h1 className="font-display text-4xl font-light text-luxury-cream -mt-8 mb-4">Page Not Found</h1>
        <p className="font-body text-sm text-luxury-light mb-8">The page you're looking for doesn't exist.</p>
        <Link href="/" className="btn-luxury inline-block">Back to Home</Link>
      </div>
    </div>
  );
}
