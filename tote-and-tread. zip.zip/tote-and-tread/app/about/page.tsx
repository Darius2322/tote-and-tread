import ShopLayout from '@/components/layout/ShopLayout';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'About Us', description: 'The story behind Tote & Tread luxury bags and footwear.' };

export default function AboutPage() {
  return (
    <ShopLayout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-24">
        <div className="text-center mb-16">
          <span className="font-body text-xs tracking-[0.4em] uppercase text-gold font-semibold">Our Story</span>
          <h1 className="font-display text-6xl font-light mt-2" style={{ color: 'var(--text-primary)' }}>About <span className="text-gold-gradient italic">Tote & Tread</span></h1>
          <div className="divider-gold mt-6" />
        </div>

        <div className="prose max-w-none space-y-8">
          {[
            { title: 'Our Story', body: 'Tote & Tread was born from a simple belief: that luxury should be accessible without compromise. Founded by fashion enthusiasts with a passion for exceptional craftsmanship, we curate premium bags and footwear that elevate every moment of your day.' },
            { title: 'Our Mission', body: 'To make luxury fashion an everyday experience — delivering meticulously crafted bags and footwear that combine timeless elegance with modern sensibility. Every piece in our collection is selected to meet the highest standards of quality, design, and durability.' },
            { title: 'Our Vision', body: 'To become the leading luxury fashion destination in Africa and beyond, recognized for our commitment to quality, authenticity, and customer experience. We envision a world where every individual can step into their story with confidence and style.' },
            { title: 'Why Choose Tote & Tread', body: 'Because we believe you deserve the best. Our curated selection features only the finest materials and craftsmanship. Our team personally vets every product, and our customer service team is always just a WhatsApp message away. We don\'t just sell accessories — we curate experiences.' },
          ].map(({ title, body }) => (
            <div key={title} className="card-luxury p-8">
              <h2 className="font-display text-3xl font-light text-gold mb-4">{title}</h2>
              <p className="font-body text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{body}</p>
            </div>
          ))}
        </div>
      </div>
    </ShopLayout>
  );
}
