import { redirect } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import ShopLayout from '@/components/layout/ShopLayout';
import { User, ShoppingBag, Heart, Bell, Receipt, Package } from 'lucide-react';

export const metadata = { title: 'My Dashboard' };

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login?redirect=/user/dashboard');

  const [
    { data: profile },
    { count: orderCount },
    { count: wishlistCount },
    { count: notifCount },
  ] = await Promise.all([
    supabase.from('profiles').select('*').eq('id', user.id).single(),
    supabase.from('orders').select('*', { count: 'exact', head: true }).eq('user_id', user.id),
    supabase.from('wishlists').select('*', { count: 'exact', head: true }).eq('user_id', user.id),
    supabase.from('notifications').select('*', { count: 'exact', head: true }).eq('user_id', user.id).eq('is_read', false),
  ]);

  const cards = [
    { icon: ShoppingBag, label: 'My Orders', count: orderCount || 0, href: '/user/orders', color: 'text-blue-400' },
    { icon: Heart, label: 'Wishlist', count: wishlistCount || 0, href: '/user/wishlist', color: 'text-red-400' },
    { icon: Bell, label: 'Notifications', count: notifCount || 0, href: '/user/notifications', color: 'text-yellow-400' },
    { icon: Receipt, label: 'Receipts', count: 0, href: '/user/receipts', color: 'text-green-400' },
    { icon: Package, label: 'Pending Cart', count: 0, href: '/shop/cart', color: 'text-purple-400' },
    { icon: User, label: 'My Profile', count: 0, href: '/user/profile', color: 'text-gold' },
  ];

  return (
    <ShopLayout>
      <div className="max-w-5xl mx-auto px-4 py-16 sm:px-6">
        <div className="mb-10">
          <p className="font-body text-xs text-gold tracking-widest uppercase mb-1">Welcome back</p>
          <h1 className="font-display text-4xl font-light" style={{ color: 'var(--text-primary)' }}>
            {profile?.full_name || 'Valued Customer'}
          </h1>
          <p className="font-body text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>{user.email}</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {cards.map(({ icon: Icon, label, count, href, color }) => (
            <Link key={href} href={href} className="card-luxury p-6 flex flex-col gap-3 group">
              <div className={`${color}`}><Icon size={24} strokeWidth={1.5} /></div>
              <div>
                <p className="font-body text-xs tracking-widest uppercase" style={{ color: 'var(--text-secondary)' }}>{label}</p>
                {count > 0 && <p className="font-display text-3xl font-light text-gold mt-1">{count}</p>}
              </div>
              <span className="font-body text-xs text-gold opacity-0 group-hover:opacity-100 transition-opacity">View →</span>
            </Link>
          ))}
        </div>
      </div>
    </ShopLayout>
  );
}
