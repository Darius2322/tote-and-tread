import { redirect } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import ShopLayout from '@/components/layout/ShopLayout';
import { format } from 'date-fns';
import { Bell } from 'lucide-react';

export const metadata = { title: 'Notifications' };

const TYPE_ICONS: Record<string, string> = {
  order_update: '📦',
  promotion: '🎉',
  restock: '🔔',
  general: '💌',
};

export default async function NotificationsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');

  const { data: notifications } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(50);

  // Mark all as read
  await supabase.from('notifications').update({ is_read: true }).eq('user_id', user.id).eq('is_read', false);

  return (
    <ShopLayout>
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-16">
        <div className="mb-10">
          <Link href="/user/dashboard" className="font-body text-xs text-luxury-light hover:text-gold transition-colors mb-4 block">← Dashboard</Link>
          <h1 className="font-display text-4xl font-light" style={{ color: 'var(--text-primary)' }}>Notifications</h1>
        </div>

        {!notifications?.length ? (
          <div className="text-center py-20">
            <Bell size={48} strokeWidth={1} className="mx-auto text-luxury-light mb-4" />
            <p className="font-display text-2xl text-luxury-light">No notifications yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {notifications.map(n => (
              <div key={n.id} className={`card-luxury p-5 flex gap-4 ${!n.is_read ? 'border-gold/40' : ''}`}>
                <span className="text-xl flex-shrink-0">{TYPE_ICONS[n.type] || '💌'}</span>
                <div className="flex-1 min-w-0">
                  <p className="font-body text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{n.title}</p>
                  <p className="font-body text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{n.message}</p>
                  <p className="font-body text-[10px] text-luxury-light mt-2">{format(new Date(n.created_at), 'MMM d, yyyy · h:mm a')}</p>
                </div>
                {!n.is_read && <div className="w-2 h-2 rounded-full bg-gold flex-shrink-0 mt-1" />}
              </div>
            ))}
          </div>
        )}
      </div>
    </ShopLayout>
  );
}
