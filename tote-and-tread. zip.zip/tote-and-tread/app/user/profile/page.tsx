'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import ShopLayout from '@/components/layout/ShopLayout';
import { createClient } from '@/lib/supabase/client';
import { updateProfileSchema } from '@/lib/validation';
import toast from 'react-hot-toast';
import { useRouter } from 'next/navigation';

export default function ProfilePage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  const { register, handleSubmit, reset, formState: { errors } } = useForm({ resolver: zodResolver(updateProfileSchema) });

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      if (!user) { router.push('/auth/login'); return; }
      const { data } = await supabase.from('profiles').select('*').eq('id', user.id).single();
      if (data) reset({ full_name: data.full_name || '', phone: data.phone || '', theme_preference: data.theme_preference || 'dark' });
      setLoading(false);
    });
  }, []);

  async function onSubmit(data: any) {
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase.from('profiles').update(data).eq('id', user.id);
    if (error) { toast.error('Update failed'); } else {
      toast.success('Profile updated');
      if (data.theme_preference) {
        localStorage.setItem('theme', data.theme_preference);
        document.documentElement.setAttribute('data-theme', data.theme_preference);
      }
    }
    setSaving(false);
  }

  async function signOut() {
    await supabase.auth.signOut();
    router.push('/');
  }

  if (loading) return <ShopLayout><div className="max-w-lg mx-auto px-4 py-20"><div className="skeleton h-96" /></div></ShopLayout>;

  return (
    <ShopLayout>
      <div className="max-w-lg mx-auto px-4 sm:px-6 py-16">
        <Link href="/user/dashboard" className="font-body text-xs text-luxury-light hover:text-gold transition-colors mb-6 block">← Dashboard</Link>
        <h1 className="font-display text-4xl font-light mb-10" style={{ color: 'var(--text-primary)' }}>My Profile</h1>
        <form onSubmit={handleSubmit(onSubmit)} className="card-luxury p-8 space-y-7">
          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Full Name</label>
            <input {...register('full_name')} className="input-luxury" />
            {errors.full_name && <p className="mt-1 text-xs text-red-400">{errors.full_name.message as string}</p>}
          </div>
          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Phone</label>
            <input {...register('phone')} className="input-luxury" placeholder="+254..." />
            {errors.phone && <p className="mt-1 text-xs text-red-400">{errors.phone.message as string}</p>}
          </div>
          <div>
            <label className="font-body text-xs font-semibold tracking-widest uppercase text-luxury-light block mb-2">Theme</label>
            <select {...register('theme_preference')} className="w-full bg-transparent border-b-2 border-gold/30 py-3 font-body text-sm focus:outline-none focus:border-gold" style={{ color: 'var(--text-primary)' }}>
              <option value="dark">Dark Mode</option>
              <option value="light">Light Mode</option>
              <option value="system">System</option>
            </select>
          </div>
          <button type="submit" disabled={saving} className="btn-luxury w-full">{saving ? 'Saving...' : 'Save Changes'}</button>
        </form>
        <button onClick={signOut} className="w-full mt-4 py-3 border border-red-500/30 text-red-400 hover:bg-red-500/10 font-body text-xs font-semibold tracking-widest uppercase transition-colors">Sign Out</button>
      </div>
    </ShopLayout>
  );
}
