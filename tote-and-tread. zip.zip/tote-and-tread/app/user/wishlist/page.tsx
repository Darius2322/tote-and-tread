import { redirect } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import ShopLayout from '@/components/layout/ShopLayout';
import ProductCard from '@/components/shop/ProductCard';

export const metadata = { title: 'My Wishlist' };

export default async function WishlistPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login?redirect=/user/wishlist');

  const { data: items } = await supabase
    .from('wishlists')
    .select('*, products(*)')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  const products = items?.map(i => i.products).filter(Boolean) || [];

  return (
    <ShopLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="mb-10">
          <Link href="/user/dashboard" className="font-body text-xs text-luxury-light hover:text-gold transition-colors mb-4 block">← Dashboard</Link>
          <h1 className="font-display text-4xl font-light" style={{ color: 'var(--text-primary)' }}>My Wishlist <span className="text-luxury-light font-body text-lg">({products.length})</span></h1>
        </div>

        {!products.length ? (
          <div className="text-center py-20">
            <p className="font-display text-3xl text-luxury-light mb-3">Your wishlist is empty</p>
            <Link href="/shop/products" className="btn-luxury inline-block mt-4">Discover Products</Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {products.map((p: any) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
      </div>
    </ShopLayout>
  );
}
