import { redirect } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import ShopLayout from '@/components/layout/ShopLayout';
import ReceiptDownload from '@/components/user/ReceiptDownload';
import { format } from 'date-fns';

export const metadata = { title: 'My Receipts' };

export default async function ReceiptsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');

  const { data: receipts } = await supabase
    .from('receipts')
    .select('*, orders(order_number, total, created_at, order_items(*))')
    .eq('user_id', user.id)
    .order('generated_at', { ascending: false });

  return (
    <ShopLayout>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16">
        <div className="mb-10">
          <Link href="/user/dashboard" className="font-body text-xs text-luxury-light hover:text-gold transition-colors mb-4 block">← Dashboard</Link>
          <h1 className="font-display text-4xl font-light" style={{ color: 'var(--text-primary)' }}>Receipts</h1>
        </div>

        {!receipts?.length ? (
          <div className="text-center py-20">
            <p className="font-display text-3xl text-luxury-light">No receipts yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {receipts.map(r => (
              <div key={r.id} className="card-luxury p-6 flex items-center justify-between gap-4">
                <div>
                  <p className="font-body text-xs text-luxury-light">Receipt #</p>
                  <p className="font-body font-bold text-sm text-gold">{r.receipt_number}</p>
                  <p className="font-body text-xs text-luxury-light mt-1">Order: {(r.orders as any)?.order_number}</p>
                  <p className="font-body text-xs text-luxury-light">{format(new Date(r.generated_at), 'MMM d, yyyy · h:mm a')}</p>
                </div>
                <div className="text-right flex flex-col items-end gap-3">
                  <p className="font-body font-bold text-gold">KSh {(r.orders as any)?.total?.toLocaleString()}</p>
                  <ReceiptDownload receipt={r} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </ShopLayout>
  );
}
