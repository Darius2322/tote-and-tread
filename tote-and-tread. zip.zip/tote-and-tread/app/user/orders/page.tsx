import { redirect } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import ShopLayout from '@/components/layout/ShopLayout';
import { format } from 'date-fns';

export const metadata = { title: 'My Orders' };

const STATUS_STYLES: Record<string, string> = {
  pending: 'text-yellow-400 bg-yellow-400/10',
  confirmed: 'text-blue-400 bg-blue-400/10',
  processing: 'text-purple-400 bg-purple-400/10',
  shipped: 'text-cyan-400 bg-cyan-400/10',
  delivered: 'text-green-400 bg-green-400/10',
  cancelled: 'text-red-400 bg-red-400/10',
  refunded: 'text-orange-400 bg-orange-400/10',
};

export default async function OrdersPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login?redirect=/user/orders');

  const { data: orders } = await supabase
    .from('orders')
    .select('*, order_items(product_name, quantity, price, product_image)')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  return (
    <ShopLayout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16">
        <div className="mb-10">
          <Link href="/user/dashboard" className="font-body text-xs text-luxury-light hover:text-gold transition-colors mb-4 block">← Dashboard</Link>
          <h1 className="font-display text-4xl font-light" style={{ color: 'var(--text-primary)' }}>My Orders</h1>
        </div>

        {!orders?.length ? (
          <div className="text-center py-20">
            <p className="font-display text-3xl text-luxury-light mb-3">No orders yet</p>
            <Link href="/shop/products" className="btn-luxury inline-block mt-4">Start Shopping</Link>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map(order => (
              <div key={order.id} className="card-luxury p-6">
                <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                  <div>
                    <p className="font-body text-xs text-luxury-light">Order #</p>
                    <p className="font-body font-bold text-sm text-gold">{order.order_number}</p>
                    <p className="font-body text-xs text-luxury-light mt-1">{format(new Date(order.created_at), 'MMM d, yyyy')}</p>
                  </div>
                  <div className="text-right">
                    <span className={`font-body text-xs font-bold tracking-widest uppercase px-3 py-1 ${STATUS_STYLES[order.status] || 'text-luxury-light bg-luxury-dark'}`}>
                      {order.status}
                    </span>
                    <p className="font-body font-bold text-lg text-gold mt-2">KSh {order.total?.toLocaleString()}</p>
                  </div>
                </div>
                <div className="flex gap-3 overflow-x-auto pb-2">
                  {(order.order_items as any[])?.map((item, i) => (
                    <div key={i} className="flex-shrink-0 flex items-center gap-2 bg-luxury-dark p-2 min-w-0">
                      {item.product_image && <img src={item.product_image} alt="" className="w-10 h-10 object-cover" />}
                      <div className="min-w-0">
                        <p className="font-body text-xs text-luxury-cream truncate max-w-[120px]">{item.product_name}</p>
                        <p className="font-body text-[10px] text-luxury-light">Qty: {item.quantity}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </ShopLayout>
  );
}
