// Auto-generated types for Supabase
// Regenerate with: npm run db:generate

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type UserRole = 'customer' | 'admin';
export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
export type ProductBadge = 'trending' | 'best_seller' | 'premium' | 'new' | 'sale';
export type NotificationType = 'order_update' | 'promotion' | 'restock' | 'general';
export type PromotionDisplay = 'banner' | 'popup' | 'notification_bar';

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: { id: string; email: string; full_name: string | null; phone: string | null; avatar_url: string | null; role: UserRole; theme_preference: string; email_notifications: boolean; push_notifications: boolean; created_at: string; updated_at: string; };
        Insert: { id: string; email: string; full_name?: string | null; phone?: string | null; role?: UserRole; };
        Update: { full_name?: string | null; phone?: string | null; avatar_url?: string | null; theme_preference?: string; email_notifications?: boolean; push_notifications?: boolean; };
      };
      products: {
        Row: { id: string; name: string; slug: string; description: string | null; price: number; compare_at_price: number | null; category_id: string | null; images: string[]; stock_quantity: number; low_stock_threshold: number; sku: string | null; badge: ProductBadge | null; is_active: boolean; is_featured: boolean; sizes: string[]; colors: string[]; tags: string[]; view_count: number; purchase_count: number; meta_title: string | null; meta_description: string | null; created_at: string; updated_at: string; };
        Insert: Omit<Database['public']['Tables']['products']['Row'], 'id' | 'created_at' | 'updated_at' | 'view_count' | 'purchase_count'>;
        Update: Partial<Database['public']['Tables']['products']['Insert']>;
      };
      categories: {
        Row: { id: string; name: string; slug: string; description: string | null; image_url: string | null; display_order: number; is_active: boolean; created_at: string; };
        Insert: Omit<Database['public']['Tables']['categories']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['categories']['Insert']>;
      };
      orders: {
        Row: { id: string; order_number: string; user_id: string | null; status: OrderStatus; subtotal: number; discount_amount: number; shipping_amount: number; total: number; currency: string; shipping_address: Json | null; notes: string | null; whatsapp_sent: boolean; payment_method: string | null; payment_reference: string | null; delivered_at: string | null; created_at: string; updated_at: string; };
        Insert: Omit<Database['public']['Tables']['orders']['Row'], 'id' | 'order_number' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['orders']['Insert']>;
      };
      order_items: {
        Row: { id: string; order_id: string; product_id: string | null; product_name: string; product_image: string | null; price: number; quantity: number; size: string | null; color: string | null; subtotal: number; };
        Insert: Omit<Database['public']['Tables']['order_items']['Row'], 'id'>;
        Update: never;
      };
      cart_items: {
        Row: { id: string; user_id: string; product_id: string; quantity: number; size: string | null; color: string | null; created_at: string; updated_at: string; };
        Insert: Omit<Database['public']['Tables']['cart_items']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: { quantity?: number; };
      };
      wishlists: {
        Row: { id: string; user_id: string; product_id: string; created_at: string; };
        Insert: Omit<Database['public']['Tables']['wishlists']['Row'], 'id' | 'created_at'>;
        Update: never;
      };
      reviews: {
        Row: { id: string; product_id: string; user_id: string; rating: number; title: string | null; body: string | null; is_verified_purchase: boolean; is_approved: boolean; created_at: string; };
        Insert: Omit<Database['public']['Tables']['reviews']['Row'], 'id' | 'created_at' | 'is_approved' | 'is_verified_purchase'>;
        Update: { rating?: number; title?: string | null; body?: string | null; };
      };
      notifications: {
        Row: { id: string; user_id: string; type: NotificationType; title: string; message: string; data: Json; is_read: boolean; created_at: string; };
        Insert: Omit<Database['public']['Tables']['notifications']['Row'], 'id' | 'created_at'>;
        Update: { is_read?: boolean; };
      };
      promotions: {
        Row: { id: string; title: string; description: string | null; image_url: string | null; button_text: string | null; button_url: string | null; display_type: PromotionDisplay; is_active: boolean; discount_percent: number | null; starts_at: string | null; ends_at: string | null; created_by: string | null; created_at: string; updated_at: string; };
        Insert: Omit<Database['public']['Tables']['promotions']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['promotions']['Insert']>;
      };
      gallery: {
        Row: { id: string; title: string | null; image_url: string; category: string | null; display_order: number; is_active: boolean; created_at: string; };
        Insert: Omit<Database['public']['Tables']['gallery']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['gallery']['Insert']>;
      };
      receipts: {
        Row: { id: string; order_id: string; user_id: string; receipt_number: string; pdf_url: string | null; generated_at: string; };
        Insert: Omit<Database['public']['Tables']['receipts']['Row'], 'id' | 'generated_at' | 'receipt_number'>;
        Update: { pdf_url?: string; };
      };
      site_settings: {
        Row: { key: string; value: Json; updated_at: string; };
        Insert: { key: string; value: Json; };
        Update: { value?: Json; };
      };
    };
    Functions: {
      is_admin: { Args: Record<never, never>; Returns: boolean; };
    };
  };
}
